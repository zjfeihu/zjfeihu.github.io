define('m3', [], function(){
    return {
        sayHello: function(){
            document.body.innerHTML += 'I`m m3<br>';
        }
    }
});