define('m2', [], function(){
    return {
        sayHello: function(){
            document.body.innerHTML += 'I`m m2<br>';
        }
    }
});