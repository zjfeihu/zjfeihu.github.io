define('main', ['m1'], function(){
    var m1 = require('m1');
    m1.sayHello();
});
