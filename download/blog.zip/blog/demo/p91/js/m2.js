define(function(module){
    module.exports = {
        sayHello: function(){
            require('log')('I`m m2');
        }
    };
});
