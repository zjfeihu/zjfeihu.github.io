define(function(module, exports){
    exports.sayHello =  function(){
        require('log')('I`m m3');
    };
});
