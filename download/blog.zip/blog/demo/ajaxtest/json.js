{
	"result": 1,
	"data": "ajaxdata"
}