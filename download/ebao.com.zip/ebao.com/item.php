<?
$ID='item';
$nav=1;
$inc('templates/layout.html');
?>