<?
$ID='admin-center';
$html='biz/bizdistributor';
$nav=0;
$pagename='商家资料';
$itemname='我的直销商';
$inc('templates/layout.html');
?>
