<?

	$ID='zzk';
	$nav=1;
	$inc('templates/layout.html');
?>