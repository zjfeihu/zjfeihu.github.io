<?
$ID='admin-center';
$html='biz/bizadvsta';
$nav=0;
$pagename='广告平台';
$itemname='效果统计';
$inc('templates/layout.html');
?>
