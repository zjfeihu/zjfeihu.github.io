<?
$ID='admin-center';
$html='biz/bizprdmanage';
$nav=0;
$pagename='商品管理';
$itemname='';
$inc('templates/layout.html');
?>
