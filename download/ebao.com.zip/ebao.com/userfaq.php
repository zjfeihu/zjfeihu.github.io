<?
$ID='admin-center';
$html='user/userfaq';
$nav=0;
$pagename='我的问答';
$itemname='问答管理';
$inc('templates/layout.html');
?>
