<?
$ID='reg';
$nav=0;
$inc('templates/layout.html');
?>
