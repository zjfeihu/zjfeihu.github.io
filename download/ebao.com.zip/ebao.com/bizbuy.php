<?
$ID='admin-center';
$html='biz/bizbuy';
$nav=0;
$pagename='购买商品';
$itemname='';
$inc('templates/layout.html');
?>
