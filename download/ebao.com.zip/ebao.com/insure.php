<?
$ID='insure';
$html='insure/insure'+($GET['s']||1);
$nav=0;
$inc('templates/layout.html');
?>
