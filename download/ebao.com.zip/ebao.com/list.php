<?
$ID='list';
$nav=1;
$type = $GET['type'];
$inc('templates/layout.html');
?>