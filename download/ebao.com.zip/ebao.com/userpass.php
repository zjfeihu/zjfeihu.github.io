<?
$ID='admin-center';
$html='user/userpass';
$nav=0;
$pagename='账号管理';
$itemname='修改密码';
$inc('templates/layout.html');
?>
