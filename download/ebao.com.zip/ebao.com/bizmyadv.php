<?
$ID='admin-center';
$html='biz/bizadvsta';
$nav=0;
$pagename='广告平台';
$itemname='我的广告';
$inc('templates/layout.html');
?>
