<?
$ID='news';
$nav=1;
$inc('templates/layout.html');
?>
