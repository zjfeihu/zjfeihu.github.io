<?
$ID='admin-center';
$html='user/userinsured';
$nav=0;
$pagename='账号管理';
$itemname='常用投保人';
$inc('templates/layout.html');
?>
