<?
$ID='admin-center';
$html='biz/biznotice';
$nav=0;
$pagename='系统公告';
$itemname='';
$inc('templates/layout.html');
?>
