<?
$ID='admin-center';
$html='biz/bizfanmanage';
$nav=0;
$pagename='财务管理';
$itemname='';
$inc('templates/layout.html');
?>