<?
$inc('widget/Jw_masklayer.js')
$inc('widget/Jw_dialog.js')
$inc('widget/Pw_login.js')
$inc('widget/Pw_shop.js')
$inc('widget/Pw_weibo.js')
$inc('public/page.js')
?>
J(function(){
	J.block({
		init:function(){
			this.advChange();//广告轮播
			this.scrollTop();//文字向上滚动
		},
		advChange:function(){
			J.block({
				init:function(){
					var Jroot=
					this.Jroot=J('#adv-change');
					this.imgbox=Jroot.find('.a-bigImg');
					this.btn=Jroot.find('li');
					this.focus=Jroot.find('li.on');
					this.index=0;
					this.bind();
					this.imgbox.css({
						position:'absolute',
						left:0,
						top:0
					}).opacity(0).hide();
					this.imgbox.eq(this.index).show().opacity(1);
					this.autoPlay();
				},
				bind:function(){
					var self=this;
					this.btn.each(function(i){
						this.hover(function(){
							if(self.index!=i){
								self.stop();
								self.play(i);
							}
						},function(){
							self.stop();
							self.autoPlay();
						});
					});
				},
				autoPlay:function(){
					var self=this;
					this.timer=setInterval(function(){
						self.play(self.index+1>=self.imgbox.nodes.length?0:self.index+1);
						
					},4000);
				},
				play:function(i){
					this.btn.eq(this.index).cls('-on');
					this.imgbox.eq(this.index).anime({o:0,t:700,after:function(){this.hide();}});
					this.btn.eq(this.index=i).cls('+on');
					this.imgbox.eq(i).anime({o:1,t:700,before:function(){this.show();}});
				},
				stop:function(){
					clearTimeout(this.timer);
				}
			});
		},
		scrollTop:function(){
			var parentNode=J("#buycard"),
			    oriNode=J("#buycardlist");
			oriNode.css({position:"absolute"});
			var cloneNode=oriNode.clone(1),
                timer,
				height=oriNode.height(),
			    top=0;
			parentNode.append(cloneNode.node);
			function rollse(){
				top--;
				oriNode.css("top",top);
			    cloneNode.css("top",(height+top));
			    if(top==-height){
				    top=0
			    }
			}
			time=setInterval(function(){
				rollse();//设置自动滚动
			},100);
			parentNode.on("mouseover",function(){
				clearInterval(time);
			}).on("mouseout",function(){
				time=setInterval(function(){
				   rollse();
				},100);
			}); 
		}
	});


});