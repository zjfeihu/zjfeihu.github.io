J(function(){
   (function(){
	   if(J.g("#addadv")){
		   var ilock=1,adv;
		   J("#add-advlist a").each(function(){
			   this.click(function(e){
				   var id=parseInt(this.attr("pid"));
				   if(this.attr("jbtn")){
					   switch(this.attr("jbtn")){
						   case "preview":{
							        var view=J.Dialog({
										cls:'Pw_box',
										title:'广告预览', //标题 
										width:240,//宽
										lock: true,//锁屏
										content: "<div class=\"viewadv\">广告"+id+"预览</div>"
									});
									J.get("",function(result){//ajax获取广告
										if(result.status){
											adv=result.statue.content;
										}
								    });
									view.show();
								 }
						         break;
						   case "addadv":{
							      alert("添加广告");
								  J.post("",function(result){
									  if(result.status){
										  alert("添加成功")
									  }
								  },{
									  action:"",
									  content:""
								  })
							     }
						         break;
						   case "checkall":{		  
									  if(ilock){
										  J("#add-advlist").find("input[type=checkbox]").attr("checked",true);
										  ilock=0;
									  }else{
										  J("#add-advlist").find("input[type=checkbox]").attr("checked",false);
										  ilock=1;
									  }
							     }
						         break;
						   case "addall":{
							      alert("批量添加");
							     }
						         break;
						   default:
						        return;
								break;
					   }
				       e.preventDefault();
				   }
			   });
		   });
	   }
   })();
});