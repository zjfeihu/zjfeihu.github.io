if(J.g('#distributor')){
	~function(){
		var d1=J.Dialog({
			width:220,
			cls:'Pw_box',
			title:'更改状态',
			content:'<div class="dist-cobox"><label>设置折扣：</label><input id="zk-numer" class="text" maxlength="4"/>折</div><div class="bottom"><button>确认修改</button></div>',
			lock:1,
			yes:function(){
				alert(111)
			}
		});
		
		var d2=J.Dialog({
			width:220,
			cls:'Pw_box',
			title:'设置折扣',
			content:'<div class="dist-cobox"><label><input type="radio" name="mx" class="radio"/>正常/审核通过</label>&nbsp;&nbsp;&nbsp;&nbsp;<label><input type="radio" name="mx" class="radio"/>禁用</label></div><div class="bottom"><button jbtn="yes">确认修改</button></div>',
			lock:1,
			yes:function(){
				alert(111)
			}
			
		});
		
		J('#distributor').click(function(evt){
			var Jtg=J(evt.target);
			if(Jtg.tag('A')){
				switch(Jtg.attr('jbtn')){
					case 'zt':
						d1.show();
						return;
					case 'zk':
						d2.show();
						return;
				
				}
			}
		});
		J('#zk-numer').on('keyup',function(){
			//this.val(parseFloat(this.val())||'');
		}).on('blur',function(){
			this.val(parseFloat(this.val())||'');
		});
	}();
}