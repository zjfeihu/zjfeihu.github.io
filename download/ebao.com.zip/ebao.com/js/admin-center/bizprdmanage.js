if(J.g("#prdmanage")){
	(function(){
		var ilock=1;
		var number=/^\d+$/;
		J("#prdmanage").find("i").each(function(){
			this.on("click",function(){
				if(ilock){
					var _this=this;
					var _next=this.parent().next("input");
					var _gval=parseFloat(this.html());
					
					this.parent().cls("+hidden");
					_next.cls("-hidden").val(parseFloat(this.html()));
					_next.node.focus();
					_next.on("blur",function(){
						var _value=parseFloat(this.val());
						if(_value<0||!number.test(_value)){
						   alert("请填写正确的价格")
						   return;
						}else{
							if(parseFloat(this.val())!=_gval){
								J.post("",function(result){//ajax提交数据
									if(result.status){
										
									}	
								},{
									action:'',
									price:''
								});
							}
							_next.cls("+hidden");
							_this.html(_next.val());
							_this.parent().cls("-hidden");
						}
						
					});
				}
			});
		});
		J("#prdmanage").find("a.edit-price").each(function(){
			this.on("click",function(e){
				var _this=this;
				var _input=this.parent().prev().prev().find("input");
				var _span=this.parent().prev().prev().find("span");
				var _i=this.parent().prev().prev().find("i");
				var _gval=parseFloat(_i.html());
				if(ilock){
					this.html("保存")
					_input.cls("-hidden").val(parseFloat(_i.html()));
					_input.node.focus();
					_span.cls("+hidden");
					ilock=0;
				}else{
					if(parseFloat(_input.val())!=_gval){
						J.post("",function(result){//ajax提交数据
							if(result.status){
								
							}	
						},{
							action:'',
							price:''
						});
					}
					_input.cls("+hidden");
					_i.html(_input.val());
					_span.cls("-hidden");
					_this.html("修改售价");
					ilock=1;
				}
				_input.on("blur",function(){
					if(parseFloat(this.val())<0||!number.test(parseFloat(this.val()))){
					   alert("请填写正确的价格")
					   return;
					}
				});
				e.preventDefault();
			});
		});
	})();
}