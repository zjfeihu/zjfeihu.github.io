if(J.g('#userorder')){
~function(){
	J('#orderstatus').on('change',function(){
		this.parent('form').node.submit();
	});
	if(J.g('#page-nav')){//分页逻辑
		J('#page-nav a').click(function(){
			J('#J_PageNum').val(this.attr('num'));
			this.parent('form').node.submit();
		});
		J('#J_PageNum').on('keyup',function(){
			this.val(this.val().replace(/\D/,''));
		}).on('blur',function(){
			this.val(this.val().replace(/\D/,''));
		});
	}
	var d1=J.Dialog({
		cls:'Pw_box',
		title:'保险卡激活信息', //标题 
		width:640,//宽
		lock: true,//锁屏
		content: ''
	});
	J(document).click(function(evt){
		var Jtg=J(evt.target);
		switch(Jtg.attr('jbtn')){
			case '激活':
				J.get(Jtg.attr('href'),function(res){
					if(res=J.parseJson(res)){
						if(res.res==1){
							d1.set({
								width:640,
								title:'保险卡激活信息', //标题 
								content: '<div class="jh-card">\
								<table cellPadding="1" cellSpacing="0" border="1" width="100%">\
									<tr align="center" bgcolor="#ffe3d5">\
										<th width="170">卡名称</th>\
										<th width="150">账号</th>\
										<th width="65">密码</th>\
										<th width="125">激活截止日期</th>\
										<th width="70">保费(元)</th>\
									</tr>'
									+(function(){
										var ht='';
										J.each(res.data,function(){
											ht+='<tr align="center">\
												<td>'+this.pname+'</td>\
												<td>'+this.cardid+'</td>\
												<td>'+this.cardpwd+'</td>\
												<td>'+this.date+'</td> \
												<td>'+this.price+'</td>\
											</tr>';
										});
										return ht;
									})()
								+'</table>\
								<div style="text-align:center; padding-top: 10px"><a href="#"  jbtn="激活邮件" url="'+res.sendMailUrl+'">重新发送激活邮件</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="'+res.activeUrl+'" target="_blank">立即激活</a></div></div>'  //显示的内容			
							}).show();
						}else{
							d1.set({
								title:'系统提示',
								content:'<div style="padding:8px">'+res.msg+'</div>'
							}).show();
						
						}
					}
				});
				evt.preventDefault();
				break;
			case '激活邮件':
				J.get(Jtg.attr('url'),function(result){
					if(result=J.parseJson(result)){
						if(result.res==1){
							alert(result.msg);
						}else{
							alert(result.msg);
						}
					}
				});
				evt.preventDefault();
				break;
			case '付款':
			    if(!Jtg.attr('data-url')){
					return;	
				}
				J.get(Jtg.attr('data-url'),function(result){
					if(result=J.parseJson(result)){
						if(result.res==1){
							location.href=Jtg.attr('href');
						}else{
							d1.set({
								width:430,
								title:'系统提示',
								content:'<div class="P_box"><p class="P_warn"><strong>'+result.msg+'</strong><br/>修改超保日期：<input id="ep_date" class="P_text" type="calendar"/></p></div><div class="bottom"><button jbtn="yes">确认修改</button></div>',
								yes:function(){
									var date=J('#ep_date').val();
									
									
								
									J.get(Jtg.attr('data-editdate-url'),function(result){
										if(result=J.parseJson(result)){
											if(result.res==1){
												alert('修改成功！');
												location.href=location.href;
											}else{
												alert('修改失败，请重试！');
												
											}
										
										}
									
									});
								
								}
							}).show();
							
						}
					}
				});
				evt.preventDefault();
				break;
		}
	});
	
}();
}