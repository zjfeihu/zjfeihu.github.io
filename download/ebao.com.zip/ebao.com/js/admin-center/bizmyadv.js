J(function(){
	(function(){
		if(J.g("#myadv")){
			var dialogs={};
			var id;
			J.each([{
				name:'viewAdv',
				cls:'Pw_box',
				title:'预览广告',
				content:'<div id="d1"></div>',
				width:240,
				lock:1,
				yes:function(){}
			},
			{
				name:'getAdvCode',
				cls:'Pw_box',
				width:370,
				title:'获取广告代码',
				content:'<div id="d2"></div>',
				yes:function(){
				    var _text=J("#textarea_"+id+"").val();
					J.copy(_text);
					alert("广告代码复制成功，您可以在其他网站上插入您的广告代码来推广您的产品");
					dialogs.getAdvCode.hide();
				}		
				
			},
			{
				name:'delAdv',
				cls:'Pw_box',
				width:380,
				title:'删除广告',
				content:'<div class="P_box">\
									<p class="P_warn"><strong>您确定要删除此广告吗？</strong><br />删除后可以从广告平台再次添加此广告。</p>\
									</div>\
									<p class="bottom"><input type="button" class="pbtn" value="确认删除"></p>',
				yes:function(){
					J.post("",function(result){//ajax删除广告
						if(result.status){
							var tt=J.Tips({
								content:"删除成功",
								cls:"Tips-del",
								stopTime:1000,
								animateTime:500
							}).show().remove();
							dialogs.delAdv.remove();
						}
					},{
						action:"",
						id:id
					});
				}		
				
			}
			],function(){
				dialogs[this.name]=J.Dialog(this);
			});
			
			J("#myadv").click(function(evt){
				var obj=J(evt.target);
				id=parseInt(obj.attr("pid"));
				var left=obj.offsetLeft();
				var top=obj.offsetTop();
				switch(obj.attr("jbtn")){
					case "preview":{
						/*var adv;
						J.get("",function(result){//ajax获取广告
							if(result.status){
								adv=result.statue.content;
							}
						});*/
						J("#d1").html('<div class="viewadv">广告'+id+'预览</div>');
						dialogs.viewAdv.show();
						evt.preventDefault();
					}
					break;
					case "advcode":{
						/*var adv;
						J.get("",function(result){//ajax获取广告
							if(result.status){
								adv=result.statue.content;
							}
						});*/
						J("#d2").html('<div class="P_box">\
									              <h3>复制以下广告代码并插入到您的网站中</h3>\
												  <p align="center"><textarea name="textarea_'+id+'" id="textarea_'+id+'" class="textarea">广告代码'+id+'</textarea></p>\
											  </div>\
												  <p class="bottom"><input type="button" name="button_'+id+'" id="button_'+id+'" class="pbtn" value="复制代码" jbtn="yes" /></p>');
						dialogs.getAdvCode.set({top:top+20,left:left-300}).show();
						evt.preventDefault();
					}
					break;
					case "deladv":{
						dialogs.delAdv.show();
						evt.preventDefault();
					}
					break;
					default:
					    return;
					break;
				}
			});
		}
			J.method("copy",function(txt){
				if(window.clipboardData) {  
					window.clipboardData.clearData();  
					window.clipboardData.setData("Text", txt); 
			    } else if(navigator.userAgent.indexOf("Opera") != -1) {  
				    window.location = txt;  
			    } else if (window.netscape) {  
				   try {  
						netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");  
				   } catch (e) {  
						alert("如果您正在使用FireFox！\n请在浏览器地址栏输入'about:config'并回车\n然后将'signed.applets.codebase_principal_support'设置为'true'");  
				   }  
				   var clip = Components.classes['@mozilla.org/widget/clipboard;1'].createInstance(Components.interfaces.nsIClipboard);  
				   if (!clip) return;  
				   var trans = Components.classes['@mozilla.org/widget/transferable;1'].createInstance(Components.interfaces.nsITransferable);  
				   if (!trans) return;  
				   trans.addDataFlavor('text/unicode');  
				   var str = new Object();  
				   var len = new Object();  
				   var str = Components.classes["@mozilla.org/supports-string;1"].createInstance(Components.interfaces.nsISupportsString);  
				   var copytext = txt;  
				   str.data = copytext;  
				   trans.setTransferData("text/unicode",str,copytext.length*2);  
				   var clipid = Components.interfaces.nsIClipboard;  
				   if (!clip) return false;  
				   clip.setData(trans,null,clipid.kGlobalClipboard);  
			  }   
		});
    })();
});