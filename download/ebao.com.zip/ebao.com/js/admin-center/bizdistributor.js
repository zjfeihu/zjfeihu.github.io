if(J.g("#distributor")){
	
	J("#mydis").find("a").each(function(){
		var zk=1;
		//var zl=1;
		var zt=1;
	    this.click(function(evt){
			
		   _value=this.attr("jbtn");
		   if(_value){
			   switch(_value){
				   case "zl":{
					   
					  var id=parseInt(this.attr("pid"));
					  J.get("",function(result){
					     if(result.status){
							 if(result.status==0){
								 alert("资料读取失败");
							 }else{//还要根据返回值判断是销售员还是商家
								 var userinfo="aaa";
								 var d1=J.Dialog({
									 width:310,
									 cls:'Pw_box',
									 title:'详细资料',
									 content:'<div>'+userinfo+'</div>',
									 lock:0,
								 }).show();
							 }
						 }
					  })
				   }
				   break;
				   case "zk":{
					   if(zk){
						   var _val=parseFloat(this.parent('tr').find(".zktd").find('span').html());
						   this.parent('tr').find(".zktd").find('span').cls("+hidden").parent().find('input').cls("-hidden").val(_val);
						   this.html("保存");
						   zk=0;
					   }else{
						   var id=parseInt(this.attr("pid"));
						   var _val=parseFloat(this.parent('tr').find(".zktd").find('input').val());
						   this.parent('tr').find(".zktd").find('span').html(_val).cls("-hidden").parent().find('input').cls("+hidden");
						   this.html("设置折扣");
						   J.post("",function(result){
							   if(result.status){
								   alert("保存失败");
							   }
						   },{
							   action:"post",
							   id:id,
							   value:_val
						   });
						   zk=1;
					   }
				   }
				   break;
				   case "zt":{
					   if(zt){
						   this.parent('tr').find(".zttd").find('span').cls("+hidden").parent().find('select').cls("-hidden");
						   this.html("保存");
						   zt=0;
					   }else{
						   var id=parseInt(this.attr("pid"));
						   var _val=this.parent('tr').find(".zttd").find('select').val();
						   this.parent('tr').find(".zttd").find('span').html(_val).cls("-hidden").parent().find('select').cls("+hidden");
						   this.html("更改状态");
						   J.post("",function(result){
							   if(result.status){
								   alert("保存失败");
							   }
						   },{
							   action:"post",
							   id:id,
							   value:_val
						   });
						   zt=1;
					   }
				   }
				   break;
				   default:   
				   return
				   break
			   }
			   evt.preventDefault();
		   }
		});
	});
}