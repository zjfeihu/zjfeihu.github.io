if(J.g("#bizbuy")){
	(function(){
		var ilock=1;
		var d1=J.Dialog({
			width:310,
			cls:'Pw_box',
			title:'批发商品',
			content:'<div class="obuy"><h4>保险礼品-九九祥福E款保险卡</h4><p><span id="kucun" style="color:red">库存：<strong>200</strong>套</span></p><p><label for="buyNum">购买数量：</label><input type="text" id="buyNum" name="buyNum" class="buyNum" maxlength="6" /> <span id="bMsg" style="color:red"></span></p><p>总 价 格：<span id="cprice"></span>元</p><p class="bottom"><input jbtn="yes" type="button" name="con-buy" id="con-buy" value="确认购买" class="pbtn" /></p></div>',
			lock:0,
			yes:function(){
				if(ilock){
				   alert("到付款页面去吧！")
			    } 
			}
		});
		J("a.pifa-btn").each(function(){
			this.click(function(e){
				var minNum=parseInt(this.attr("minNum"));//最低购买数量
				var pid=parseInt(this.attr("pid"));
				var maxNum=100;
				var price=parseFloat(this.attr("price"));
				d1.set({left:this.offsetLeft()-100,top:this.offsetTop()+30});
				d1.show();
				/*J.get("",function(result){
					if(result.status){
						maxNum=parseInt(eval(0+','+result.content).content);
					}
				});*/
				J("#buyNum").val(minNum);
				J("#cprice").html(minNum*price);
				//J("#kucun").html(maxNum);
				J("#buyNum").on("change",function(){
			        var _value=this.val();
					var number=/^\d+$/;
					if(_value>maxNum){
						J("#bMsg").html("批发数量不能多于"+maxNum+"套");
						ilock=0;
					}else if(_value<minNum){
						J("#bMsg").html("批发数量不能少于"+minNum+"套");
						ilock=0;
					}else if(!number.test(_value)){
						J("#bMsg").html("批发数量必须为正整数");
						ilock=0;
					}else{
						J("#bMsg").html("");
						J("#cprice").html(_value*price);
						ilock=1;
					}
					
		        });	
				e.preventDefault();
		    });
		});
	})();
}