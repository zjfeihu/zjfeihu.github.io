<?
$inc('widget/Jw_masklayer.js')
$inc('widget/Jw_dialog.js')
$inc('widget/Pw_login.js')
$inc('widget/Pw_shop.js')
$inc('widget/Pw_weibo.js')
$inc('public/page.js')
?>
J(function(){
	J.block({
		init:function(){
			this.setCount();//设置份数
			//this.savecard();//立即投保验证
			this.addshop();//加入购物车
		},
		setCount:function(){
			function setHtml(){
				J('#ins_price').html((J('#ins_price').attr('price')*J('#count').val()).toFixed(2));
			}
			if(J('#count').tag('SELECT')){
				J('#count').on('change',function(){
					setHtml();
				});
			}else{//直接选择份数
				var selected=J('#countbox a.sel-h').node;
				J('#countbox a').click(function(evt){
					if(this.node!=selected){
						J(selected).cls('-sel-h');
						selected=this.cls('+sel-h').node;
						J('#count').val(this.attr('datacount'));
						setHtml();
						
					}
					evt.preventDefault();
				});
			}
		},
		savecard:function(){
			var me=this;
			J('#proForm').on('submit',function(evt){//立即投保逻辑,需要先验证
				var form=this.node;
				if(J('#savecard').attr('data-url')){
					J.get(J('#savecard').attr('data-url')+'&num='+J('#count').val(),function(result){
						if(result=J.parseJson(result)){
							if(result.res==1){
								form.submit();
							}else{
								me.dialog(result.msg)
							}
						}
					});
					evt.preventDefault();
				}
				
			});
		},
		addshop:function(){
			J('#addshop').click(function(evt){
				J.Pw_shop.position({
					left:this.offsetLeft()-270,
					top:this.offsetTop()-66
				}).add(this.attr('data-url')+'&num='+J('#count').val());
				evt.preventDefault();
			});
			/*
			var me=this;
			J('#addshop').click(function(evt){
				J.get(J('#addshop').attr('data-url')+'&num='+J('#count').val(),function(result){
					if(result=J.parseJson(result)){
						if(result.res==1){
							J.Pw_shop.position({
								left:this.offsetLeft()-270,
								top:this.offsetTop()-66
							}).add(this.attr('data-url'));
						}else{
							me.dialog(result.msg);
						}
					}
				});
				evt.preventDefault();
			});
			*/
		},
		dialog:function(msg){
			if(this._dialog){
				this._dialog.set({
					content:'<div style="padding:6px 8px;text-align:center;font-size:14px;">'+msg+'</div>'
				}).show();
			}else{
				this._dialog=J.Dialog({
					cls:'Pw_box',
					title:'系统提示',
					width:400,
					content:'<div style="padding:6px 8px;text-align:center;font-size:14px;">'+msg+'</div>',
					lock:1
				});
				this._dialog.show();
			}
		}
	});
});