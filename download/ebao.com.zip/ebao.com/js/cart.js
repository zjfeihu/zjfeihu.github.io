<?
$inc('widget/Jw_masklayer.js')
$inc('widget/Jw_dialog.js')
$inc('widget/Pw_login.js')
$inc('widget/Pw_weibo.js')
$inc('public/page.js')
?>
J(function(){
	J.block({
		init:function(){
			this.numset();//数量增减逻辑
			this.deleteItem();//删除购物车商品
			this.selectAll();//全选
			this.pay();//支付
			this.guessLike();//猜你喜欢tab
		},
		numset:function(){
			J('#st-data input.num').each(function(){
				var val=this.val(),
					limit=+this.attr('limitnum');
				this.on('focus',function(){
					val=this.val();
					
				}).on('keyup',function(){
					this.val(this.val().replace(/\D/g,''));
				}).on('blur',function(){
					this.val(this.val().replace(/\D/g,''));
					if(this.val()>0&&this.val()<=limit){
						setNum(this);
					}else{
						this.val(val);
					}
				});
			});
			J('#st-data span.reduce').each(function(){
				this.click(function(){
					var Jinput=this.sibling('input');
					if(+Jinput.val()>1){
						Jinput.val(Jinput.val()-1);
						setNum(Jinput);
					}
				});
			});
			J('#st-data span.add').each(function(){
				var limit=+this.sibling('input').attr('limitnum');
				this.click(function(){
					var Jinput=this.sibling('input');
					if(+Jinput.val()<limit){
						Jinput.val(+Jinput.val()+1);
						setNum(Jinput);
					}
				});
			});
			function setNum(Jinput){
				J.get(Jinput.attr('data-url')+'&num='+Jinput.val(),function(result){
					if(result){
						try{
							result=eval('('+result+')');
							if(result.res==1){
								J('#total-price').html('&yen; '+result.totalPrice);
							}
						}catch(e){}
					}
				});
			}
		},
		deleteItem:function(){
			J('#delete-items').click(function(){
				var itemIds=[];
				J('#st-data input[type=checkbox]').each(function(){
					if(this.node.checked){
						itemIds.push(this.parent('li').parent('li').attr('data-cartids'));
					}
				});
				if(!itemIds.length){
				    alert("请选择要删除的商品");
				    return;
				}else{
					var r=confirm("您确定要删除吗？");
					if(r==true){
						doDelete('cart.php?action=delCart&cartids='+itemIds);
					}else{
						return;
					}	
				}
			});
			J('#st-data a.delete-item').each(function(){
				this.click(function(){
				    var r=confirm("您确定要删除吗？");
					if(r==true){
					    doDelete(this.attr('data-url'));
					}else{
				        return;
					}
				
				});
			
			});
			function doDelete(url){
				J.get(url,function(result){
					if(result){
						try{
							result=eval('('+result+')');
							if(result.res==1){
								location.href=location.href;
							}
						}catch(e){}
					}
				});
			}
		},
		selectAll:function(){
			J('#select-all').click(function(){
				var ck=this.attr('checked');
				J('#st-data input[type=checkbox]').each(function(){
					this.node.checked=ck;
				
				});
			
			});
		
		},
		pay:function(){
			J('#st-data a.btn-pay').each(function(){
				this.click(function(){
					this.attr('href',this.attr('href')+'&item[count]='+this.parent().prev().find('input').val());
				});
			});
		},
		guessLike:function(){
			var root=J('#guess-like'),
				tabBtn=root.find('li.tab'),
				tabbox=root.find('ul.gl-content'),
				focus=0;
			tabBtn.each(function(i){
				this.click(function(){
					if(i!=focus){
						tabBtn.eq(focus).cls('-focus');
						tabbox.eq(focus).hide();
						this.cls('+focus');
						tabbox.eq(i).show();
						focus=i;
					}
				});
			
			});
		},
		end:0

	});
	
	
	
});

