<?
$inc('widget/Jw_masklayer.js')
$inc('widget/Jw_dialog.js')
$inc('widget/Pw_login.js')
$inc('widget/Jw_form.js')
$inc('widget/Pw_weibo.js')
$inc('public/page.js')
?>
J(function(){
	if(J.g('#form1')){
		var user_pass=1;
		var form1=J.Form('#form1').skin({
			name:'default',
			type:'tips,erro,null',
			data:{
				email:['邮箱的格式为example@example.com','请填写正确格式的邮箱！','请填写常用的邮箱！'],
				code:['','','验证码不能为空！'],
				password:['密码由6-16位字母，数字组成','填写正确的密码','密码不能为空！'],
				password2:['密码由6-16位字母，数字组成','密码与上一次输入不一致','重复密码不能为空！']
			}
		}).addTest('email',function(Jinput){
			Jinput.parent().find('.errobox').html('邮箱格式错误');
			J.get('reg.php?action=checkName&email='+Jinput.val(),function(result){
				if(result=J.parseJson(result)){
					if(result.res==1){
						user_pass=1;
					}else{
						user_pass=0;
						Jinput.parent().find('.errobox').html(result.msg).parent('.formbox').cls('+isErro');
					}
				}
			});
			return 1;
		}).addTest('password',function(){
			form1.doTest('password2');
			return 1;
		}).addTest('password2',function(Jfocus){
			if(J('input[name=password]',this.node).val()==Jfocus.val()){
				return 1;
			}
		});
		J('#form1').on('submit',function(evt){
			if(!user_pass){
				evt.preventDefault();
			}
		});
		
	}
	if(J.g('#tiaokuan')){
		  J(function(){
			var show=0;
			J('#tiaokuan').click(function(e){
				if(show){
				   J("#xieyi").hide();
				   show=0;
				}
				else{
					J("#xieyi").show();
				   show=1;
				}
			e.preventDefault();	
			});
		});	

	}

});