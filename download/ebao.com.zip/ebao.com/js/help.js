<?
$inc('widget/Jw_masklayer.js')
$inc('widget/Jw_dialog.js')
$inc('widget/Pw_login.js')
$inc('widget/Pw_shop.js')
$inc('widget/Pw_weibo.js')
$inc('public/page.js')
?>
J(function(){
	(function(){
		if(J.g("#content")){
			J("#printContent").click(function(e){
				window.print();//打印网页
			    e.preventDefault();
			});
			J("#addFav").click(function(e){//加入收藏夹
                try{
					window.external.addFavorite(window.location, document.title);
				}catch (e){
					try{
						window.sidebar.addPanel(document.title, window.location, "");
					}catch (e){
						alert("加入收藏失败，请使用Ctrl+D进行添加");
					}
				}
				e.preventDefault();
			});
			J("#que-cause").click(function(e){
				J("#post-cause").cls("-hidden");
			    e.preventDefault();
			});
			J("#helpnav .showchild").each(function(){
				this.click(function(e){
					this.parent('ul').find('ul').cls("+hidden");
					this.parent('ul').find('strong').cls("-down");
					if(this.parent().next("ul")){
						this.parent().next().cls("-hidden");
						this.parent().cls("+down")
						e.preventDefault();
					}
				});
			});
		}
	})();
});