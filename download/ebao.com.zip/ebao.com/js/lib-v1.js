~function(name){
	var $PID=1,
	$WIN=window,
	$DOC=document,
	$HEAD=$dom_g('head')[0],
	$bom_browser=function(){
		var ua=navigator.userAgent.toLowerCase(),
			sys={},
			s;
		(s = ua.match(/msie ([\d.]+)/)) ? sys.ie = s[1] :
		(s = ua.match(/firefox\/([\d.]+)/)) ? sys.firefox = s[1] :
		(s = ua.match(/chrome\/([\d.]+)/)) ? sys.chrome = s[1] :
		(s = ua.match(/opera.([\d.]+)/)) ? sys.opera = s[1] :
		(s = ua.match(/version\/([\d.]+).*safari/)) ? sys.safari = s[1] : 0;
		return sys;
	}(),
	$Gname=$WIN[name],	$event_add=function(){
		if($DOC.attachEvent){
			return function(node,type,fn){
				node.attachEvent('on'+type,fn); 
			};
		}else{
			return function(node,type,fn){
				node.addEventListener(type,fn,false); 
			};
		}
	}(),
	$event_rmv=function(){
		if($DOC.detachEvent){
			return function(node,type,fn){
				node.detachEvent('on'+type,fn); 
			};
		}else{
			return function(node,type,fn){
				node.removeEventListener(type,fn,false); 
			};
		}
	}(),
	$EVENTQUEUE={
		//事件队列
	},
	$event_ready=function(){
		var isReady=false, //判断onDOMReady方法是否已经被执行过
		readyList= [],//把需要执行的方法先暂存在这个数组里
		timer,//定时器句柄
		ready=function(fn) {
			if (isReady){
				fn();
			}else{
				readyList.push(fn);
			}
		},
		onDOMReady=function(){
			for(var i=0,lg=readyList.length;i<lg;i++){
				readyList[i]();
			}
			readyList = null;
		},
		bindReady = function(evt){
			if(isReady)return;
			isReady=true;
			onDOMReady();
			if($DOC.removeEventListener){
				$DOC.removeEventListener("DOMContentLoaded",bindReady,false);
			}else if($DOC.attachEvent){
				$DOC.detachEvent("onreadystatechange", bindReady);
				if($WIN == $WIN.top){
					clearInterval(timer);
					timer = null;
				}
			}
		};
		if($DOC.addEventListener){
			$DOC.addEventListener("DOMContentLoaded", bindReady, false);
		}else if($DOC.attachEvent){
			$DOC.attachEvent("onreadystatechange", function(){
				if((/loaded|complete/).test($DOC.readyState))bindReady();
			});
			if($WIN == $WIN.top){
				timer = setInterval(function(){
					try{
						isReady||$DOC.$DOCElement.doScroll('left');//在IE下用能否执行doScroll判断dom是否加载完毕
					}catch(e){
						return;
					}
					bindReady();
				},5);
			}
		}
		return ready;
	}(),	$Class=function(){
		var initializing=0,fnTest=/\b_super\b/,
			Class=function(){};
		Class.prototype={};
		Class.extend=function(prop){
			var _super = this.prototype;
			initializing=1;//锁定初始化,阻止超类执行初始化
			var _prototype=new this();//只是通过此来继承，而非创建类
			initializing=0;//解锁初始化
			function fn(name, fn) {
				return function() {
					this._super = _super[name];//保存超类方法，此this后面通过apply改变成本体类引用
					var ret = fn.apply(this, arguments);//创建方法，并且改变this指向
					return ret;//返回刚才创建的方法
				};
			}
			var _mtd;//临时变量，存方法
			for (var name in prop){//遍历传进来的所有方法
				_mtd=prop[name];
				_prototype[name] =(typeof _mtd=='function'&&
				typeof _super[name]=='function'&&
				fnTest.test(_mtd))?fn(name,_mtd):_mtd;//假如传进来的是函数，进行是否调用超类的检测来决定是否保存超类
			}
			function F() {//构造函数，假如没有被初始化，并且有初始化函数，执行初始化
				if (!initializing&&this.init)this.init.apply(this, arguments);
			}
			F.prototype=_prototype;//创建。。。
			F.constructor=F;//修正用
			F.extend=arguments.callee;
			return F;
		};
		return Class;
	}(),	$XHR=function(){
		return $WIN.XMLHttpRequest||function(X){
			var xstr=[0,'Microsoft.XMLHTTP','MSXML2.XMLHTTP.3.0','MSXML2.XMLHTTP'],
				i=4;
			while(--i){
				try {
					X = new ActiveXObject(xstr[i]);
					return function(){return X;}
				}catch(e){
					//alert('ajax对象不存在！');
				}
			}
		}();
	}(),	$isIE6=/MSIE\s*6.0/i.test(navigator.appVersion),	$EASING={
		//t:当前步数
		//b:开始位置
		//c:总改变量
		//d:总步数
		Linear: function(t,b,c,d){ return c*t/d + b; },
		slowIn:function(t,b,c,d){return c*(t/=d)*t + b;},
		slowOut:function(t,b,c,d){return -c *(t/=d)*(t-2) + b;},
		slowBoth:function(t,b,c,d){
			if ((t/=d/2) < 1) return c/2*t*t + b;
			return -c/2 * ((--t)*(t-2) - 1) + b;
		},
		In: function(t,b,c,d){
			return c*(t/=d)*t*t*t + b;
		},
		Out: function(t,b,c,d){
			return -c * ((t=t/d-1)*t*t*t - 1) + b;
		},
		Both: function(t,b,c,d){
			if ((t/=d/2) < 1) return c/2*t*t*t*t + b;
			return -c/2 * ((t-=2)*t*t*t - 2) + b;
		},
		fastIn: function(t,b,c,d){
			return (t==0) ? b : c * Math.pow(2, 10 * (t/d - 1)) + b;
		},
		fastOut: function(t,b,c,d){
			return (t==d) ? b+c : c * (-Math.pow(2, -10 * t/d) + 1) + b;
		},
		fastBoth: function(t,b,c,d){
			if (t==0) return b;
			if (t==d) return b+c;
			if ((t/=d/2) < 1) return c/2 * Math.pow(2, 10 * (t - 1)) + b;
			return c/2 * (-Math.pow(2, -10 * --t) + 2) + b;
		},
		circIn: function(t,b,c,d){
			return -c * (Math.sqrt(1 - (t/=d)*t) - 1) + b;
		},
		circOut: function(t,b,c,d){
			return c * Math.sqrt(1 - (t=t/d-1)*t) + b;
		},
		circBoth: function(t,b,c,d){
			if ((t/=d/2) < 1) return -c/2 * (Math.sqrt(1 - t*t) - 1) + b;
			return c/2 * (Math.sqrt(1 - (t-=2)*t) + 1) + b;
		},
		elasticIn: function(t,b,c,d,a,p){
			if (t==0) return b;  if ((t/=d)==1) return b+c;  if (!p) p=d*.3;
			if (!a || a < Math.abs(c)) { a=c; var s=p/4; }
			else var s = p/(2*Math.PI) * Math.asin (c/a);
			return -(a*Math.pow(2,10*(t-=1)) * Math.sin( (t*d-s)*(2*Math.PI)/p )) + b;
		},
		elasticOut: function(t,b,c,d,a,p){
			if (t==0) return b;  if ((t/=d)==1) return b+c;  if (!p) p=d*.3;
			if (!a || a < Math.abs(c)) { a=c; var s=p/4; }
			else var s = p/(2*Math.PI) * Math.asin (c/a);
			return (a*Math.pow(2,-10*t) * Math.sin( (t*d-s)*(2*Math.PI)/p ) + c + b);

		},

		elasticBoth: function(t,b,c,d,a,p){
			if (t==0) return b;  if ((t/=d/2)==2) return b+c;  if (!p) p=d*(.3*1.5);
			if (!a || a < Math.abs(c)) { a=c; var s=p/4; }
			else var s = p/(2*Math.PI) * Math.asin (c/a);
			if (t < 1) return -.5*(a*Math.pow(2,10*(t-=1)) * Math.sin( (t*d-s)*(2*Math.PI)/p )) + b;
			return a*Math.pow(2,-10*(t-=1)) * Math.sin( (t*d-s)*(2*Math.PI)/p )*.5 + c + b;
		},
		backIn: function(t,b,c,d,s){
			if (s == undefined) s = 1.70158;
			return c*(t/=d)*t*((s+1)*t - s) + b;
		},
		backOut: function(t,b,c,d,s){
			if (s == undefined) s = 1.70158;
			return c*((t=t/d-1)*t*((s+1)*t + s) + 1) + b;
		},
		backBoth: function(t,b,c,d,s){
			if (s == undefined) s = 1.70158; 
			if ((t/=d/2) < 1) return c/2*(t*t*(((s*=(1.525))+1)*t - s)) + b;
			return c/2*((t-=2)*t*(((s*=(1.525))+1)*t + s) + 2) + b;
		},
		bounceIn: function(t,b,c,d){
			return c - $EASING.bounceOut(d-t, 0, c, d) + b;
		},
		bounceOut: function(t,b,c,d){
			if ((t/=d) < (1/2.75)) {
				return c*(7.5625*t*t) + b;
			} else if (t < (2/2.75)) {
				return c*(7.5625*(t-=(1.5/2.75))*t + .75) + b;
			} else if (t < (2.5/2.75)) {
				return c*(7.5625*(t-=(2.25/2.75))*t + .9375) + b;
			} else {
				return c*(7.5625*(t-=(2.625/2.75))*t + .984375) + b;
			}
		},
		bounceBoth: function(t,b,c,d){
			if (t < d/2) return $EASING.bounceIn(t*2, 0, c, d) * .5 + b;
			else return $EASING.bounceOut(t*2-d, 0, c, d) * .5 + c*.5 + b;
		}
	},
	$ANIMEQUEQU={
		//动画队列
	},
	$ui_Drag=$Class.extend({
		init:function(opt){
			this.node=opt.node;
			this.style=opt.node.style;
			this.before=opt.before;//开始回调
			this.runing=opt.runing;//执行回调
			this.after=opt.after;//结束回调
			this.limitNode='limitNode' in opt?opt.limitNode:$WIN;//限制范围
			this.lockx=opt.lockx;
			this.locky=opt.locky;
			this.addHand(opt.hand||opt.node);//默认hand是自己
			
		},
		addHand:function(hand){
			if($isArray(hand)){
				var i=0;
				while(hand[i]){
					$event_bind(hand[i],'mousedown',this.beforeDrag,this);
					i++;
				}
				
			}else{
				$event_bind(hand,'mousedown',this.beforeDrag,this);
			}
			return this;
		},
		rmvHand:function(hand){
			if($isArray(hand)){
				var i=0;
				while(hand[i]){
					$event_unbind(hand[i],'mousedown',this.beforeDrag,this);
					i++;
				}
			}else{
				$event_bind(hand,'mousedown',this.beforeDrag,this);
			}
			return this;
		},
		beforeDrag:function(evt){
			evt.stopPropagation();//停止冒泡
			var node=this.node;
			if(evt.mouseKey!='left'||node.___resizing)return;//左键执行
			
			this.before&&this.before(evt);
			this.pType=$dom_css(node,'position');
			
			if(this.pType=='static'){
				var x=$dom_offsetLeft(node)-$dom_cssnum(node,'marginLeft'),
					y=$dom_offsetTop(node)-$dom_cssnum(node,'marginTop');
			
				$dom_css(node,{
					position:'absolute',
					left:x,
					top:y
				});
			}
			var limitNode=this.limitNode;
			if(limitNode){
				if(limitNode==$WIN){
					this.minX=0;
					this.minY=0;
					this.maxX=($DOC.documentElement.clientWidth||$DOC.body.clientWidth)-node.offsetWidth;
					this.maxY=($DOC.documentElement.scrollHeight||$DOC.body.scrollHeight)-node.offsetHeight;
				}else{
					this.minX=$dom_offsetLeft(limitNode);
					this.maxX=this.minX+$dom_cssnum(limitNode,'width')-node.offsetWidth;
					this.minY=$dom_offsetTop(limitNode);
					this.maxY=this.minY+$dom_cssnum(limitNode,'height')-node.offsetHeight;
				}
				
			}
			
			this.offsetX=evt.clientX-node.offsetLeft;//+$dom_css(node,'marginLeft');
			this.offsetY=evt.clientY-node.offsetTop;//+$dom_css(node,'marginTop');
			
			$event_bind($DOC,'mousemove',this.draging,this);
			$event_bind($DOC,'mouseup',this.drop,this);
			if($bom_browser.ie){
				this.focusHand=evt.target;
				$event_bind(this.focusHand,'losecapture',this.drop,this);//焦点丢失
				this.focusHand.setCapture(false);//设置鼠标捕获	
			}else{
				var self=this;
				this._win_blur=$WIN.onblur||null;
				$WIN.onblur=function(){
					self._win_blur&&self._win_blur();
					self.drop(evt);
				};
				evt.preventDefault();//阻止默认动作
			}
		},
		draging:function(evt){
			$WIN.getSelection?$WIN.getSelection().removeAllRanges():$DOC.selection.empty();//清除选择
			var left=evt.clientX-this.offsetX,
				top=evt.clientY-this.offsetY;
			if(this.limitNode){
				left=Math.min(Math.max(left,this.minX),this.maxX);
				top=Math.min(Math.max(top,this.minY),this.maxY);
			}
			if(!this.lockx)this.style.left=left+'px';
			if(!this.locky)this.style.top=top+'px';
			this.runing&&this.runing(evt);
		},
		drop:function(evt){
			$event_unbind($DOC,'mousemove',this.draging,this);
			$event_unbind($DOC,'mouseup',this.drop,this);
			if($bom_browser.ie){
				$event_unbind(this.focusHand,'losecapture',this.drop,this);//焦点丢失
				this.focusHand.releaseCapture();
			}else{
				$WIN.onblur=this._win_blur;
			}
			this.style.position=this.pType;
			this.after&&this.after(evt);	
		}
	}),
	$DRAGQUEQU={
		//拖放队列
	};
	function $bom_cookie(name,value,expire){
		if(typeof value!='undefined'){
			var exp = new Date(); 
			exp.setTime(exp.getTime()+(value==null?-1:(expire||2592000000)));
			$DOC.cookie=name+'='+escape(value)+';expires='+exp.toGMTString();
		}else{
			var arr = $DOC.cookie.match(new RegExp('(^| )'+name+'=([^;]*)(;|$)')); 
			return arr!=null?unescape(arr[2]):null;
		}
	}
	function $bom_docWidth(){
		return $DOC.documentElement.clientWidth||$DOC.body.clientWidth;
	}
	function $bom_docHeight(){
		return $DOC.documentElement.clientHeight||$DOC.body.clientHeight;
	}
	function $Jlazy(selector,context){
		switch(typeof selector){
			case 'string':;
			case 'object':return new $_Jlazy(selector,context);
			case 'function':return $event_ready(selector);
		}
		
	}
	function $_Jlazy(selector,context){
		if(selector==$DOC||selector==$WIN){
			this.node=selector;
		}else{
			var result=$dom_g(selector,context);
			
			if(result==null)return null;
			if(result.nodeName){
				this.node=result;
			}else{
				this.nodes=result;
				this.node=result[0];
			}
		}
	}
	function $box(func,arg1,arg2,arg3){
		var result=func.call(this,this.node,arg1,arg2,arg3);
		if(this.nodes&&result==this){
			var i=1;
			while(this.nodes[i]){
				func.call(this,this.nodes[i],arg1,arg2,arg3);
				i++;
			}
			return this;
		}else{
			return result;
		}
	}
	function $Evt(evt){
		var _evt={
			type:evt.type,
			clientX:evt.clientX,
			clientY:evt.clientY,
			target:evt.target||evt.srcElement,
			fromTarget:evt.fromElement||(evt.type=='mouseover'?evt.relatedTarget:null),
			toTarget:evt.toElement||(evt.type=='mouseout'?evt.relatedTarget:null),
			stopPropagation:function(){
				if(evt.stopPropagation){
					evt.stopPropagation();
				}else{
					evt.cancelBubble=true;
				}
			},
			mouseKey:($bom_browser.ie?{1:'left',4:'middle',2:'right'}:{0:'left',1:'middle',2:'right'})[evt.button],
			preventDefault:function(){
				if(evt.preventDefault){
					evt.preventDefault();
				}else{
					evt.returnValue = false;
				}
			}
		};
		return _evt;
	}
	function $event_bind(node,type,func,who){
		if(!node.___EVENTID){//没有有事件队列
			$EVENTQUEUE[node.___EVENTID=$PID++]=[];
		}
		var EQ=$EVENTQUEUE[node.___EVENTID];
		if(!EQ[type]){//无该类型的事件队列
			EQ[type]=[];
			$event_add(node,type,function(evt){
				var Q=EQ[type].slice(0);
				while(Q[0]){
					Q[0].func.call(Q[0].who,$Evt(evt));
					Q.shift();
				}
			});
		}
		EQ[type].push({
			func:func,
			who:who||node
		});
		return this;
	}
	function $event_unbind(node,type,func,who){
		var Q=$EVENTQUEUE[node.___EVENTID][type],i=0;
		while(Q[i]){
			if(Q[i].func==func&&Q[i].who==(who||node)){
				Q.splice(i,1);break;
			}
			i++;
		}
		return this;
	}
	function $dom_g(selector,context){
		var root=$DOC,
			idx,
			id,
			tag,
			cls,
			attr,
			nodes,
			reNodes=[];
		if(typeof selector=='object')return selector;//传入节点
		if(/^#[\w\-]+$/.test(selector)){
			return $DOC.getElementById(selector.substr(1));
		}
		selector=selector.match(/^(?:#([\w\-]+))?\s*(?:(\w+))?(?:.([\w\-]+))?(?:\[(.+)\])?$/);
		if(selector){
			id=selector[1];
			tag=selector[2];
			cls=selector[3];
			attr=selector[4];
		}else{
			return null;
		}
		if(typeof context=='object'){
			root=context;
		}else if(typeof context=='number'){
			idx=context;
		}
		if(id){
			root=$DOC.getElementById(id);
		}
		nodes=root.getElementsByTagName(tag||'*');
		if(cls||attr){
			if(cls){
				reNodes=[];
				var reg=new RegExp('\\s'+cls+'\\s');
				for(var i=0,lg=nodes.length;i<lg;i++){
					if(reg.test(' '+nodes[i].className+' ')){
						reNodes.push(nodes[i]);
					}
				}
			}
			if(attr){
				if(cls)nodes=reNodes.slice(0);
				reNodes=[];
				attr=attr.split('=');
				var key=attr[0],
					val=attr[1]||'';
				for(var i=0,lg=nodes.length;i<lg;i++){
					if(nodes[i].getAttribute(key)==val){
						reNodes.push(nodes[i]);
					}
				}
			}
		}else{
			for(var i=0,lg=nodes.length;i<lg;i++){
				reNodes[i]=nodes[i];
			}
		}
		if(idx)reNodes=reNodes[idx];
		return reNodes;
	}
	function $dom_node(node){
		if(node.indexOf('<')>-1){//非标准创建节点
			var prarent=$DOC.createElement('div');
			prarent.innerHTML=node;
			return prarent.firstChild;
		}else{
			return $DOC.createElement(node);
		}
	}
	function $dom_hcls(node,cls){
		if(new RegExp('\\s'+cls+'\\s').test(' '+node.className+' '))return !0;
		return !1;
	}
	function $dom_cls(node,cls1,cls2){
		if(cls2){
			node.className=(' '+node.className+' ')
				.replace(new RegExp('\\s+'+cls2+'\\s+'),cls1)
				.replace(/^ | $/,'');
		}else{
			if(!cls1){
				return node.className;
			}
			var _exp=cls1.substr(0,1),
				_cls=cls1.substr(1);
			if(_exp=='+'){
				if(!$dom_hcls(node,_cls))node.className+=' '+_cls.split(',').join(' ');
			}else if(_exp=='-'){
				node.className=(' '+node.className+' ')
					.replace(new RegExp('\\s+('+_cls.split(',').join('|')+')(?=\\s+)','g'),'')
					.replace(/^\s+|\s+$/g,'');
			}else if(cls1){
				return $dom_hcls(node,cls1);
			}
		}
		return this;
	}
	function $dom_css_addpx(attr,val){
		if(/width|height|left|top|right|bottom|margin|padding/.test(attr)&&/^[\-\d.]+$/.test(val)){//数值属性
			return val+'px';//加px
		}
		return val;
	}
	function $dom_css_rmvpx(attr,val){
		if(/px$/.test(val))return parseFloat(val);//去除px
		return val;
	}
	function $dom_css(node,name,value){
		if(typeof value!='undefined'){
			node.style[name]=$dom_css_addpx(name,value);
		}else if(typeof name=='object'){
			for(var key in name){
				node.style[key]=$dom_css_addpx(key,name[key]);
			}
		}else{
			if(name.indexOf(':')==-1){//无‘:’,比如'background:red'
				return $dom_css_rmvpx(name,node.style&&node.style[name]||(node.currentStyle||$DOC.defaultView.getComputedStyle(node,null))[name]);
			}else{
			
				var cssObj=name.replace(/;$/,'').split(';'),
					cssText;
				for(var i=0,lg=cssObj.length;i<lg;i++){
					cssText=cssObj[i].split(':');
					node.style[cssText[0]]=$dom_css_addpx(cssText[0],cssText[1]);
				}
			}
		}
		return this;
	}
	function $dom_attr(node,name,value){
		if(value!=undefined){
			if(typeof name=='object'){
				for(var attr in name){
					if(attr=='style'){
						node.style.cssText=name[attr];
					}if(node.nodeName=='INPUT'&&(attr=='disabled'||attr=='checked'&&/radio|checkbox/.test(node.type))
					||node.nodeName=='SELECT'&&attr=='disabled'){
						node[attr]=name[attr];
					}else{
						node.setAttribute(attr,name[attr],2);
					}
			}
			}else{
				if(name=='style'){
					node.style.cssText=value;
				}else if(node.nodeName=='INPUT'&&(name=='disabled'||name=='checked'&&/radio|checkbox/.test(node.type))
				||node.nodeName=='SELECT'&&name=='disabled'){
					node[name]=value;
				}else{
					node.setAttribute(name,value,2);
				}
			}
			return this;
		}else{
			if(name=='style'){
				return node.style.cssText;
			}else{
				return node.getAttribute(name,2)||node[name];
			}
		}
		return this;
	}
	function $dom_contains(pnode,cnode){
		if(cnode==pnode)return 1;
		if(pnode.contains){//ie下判断是不是属于dom_contains容器中的节点
			if(pnode.contains(cnode)){
				return 2;
			}
		}else if(pnode.compareDocumentPosition){//非ie下判断
			if(pnode.compareDocumentPosition(cnode)==20){
				return 2;
			}
		}
		return 0;
	}
	function $dom_cssnum(node,attr){
		var val=parseInt($dom_css(node,attr))||0;
		if(/^width|height|left|top$/.test(attr)){
			switch(attr){
				case 'left':return val||node.offsetLeft-$dom_cssnum(node,'marginLeft');
				case 'top':return val||node.offsetTop-$dom_cssnum(node,'marginTop');
				case 'width':return val
					||(node.offsetWidth
						-$dom_cssnum(node,'paddingLeft')
						-$dom_cssnum(node,'paddingRight')
						-$dom_cssnum(node,'borderLeftWidth')
						-$dom_cssnum(node,'borderRightWidth')
					);
				case 'height':return val
					||(node.offsetHeight
						-$dom_cssnum(node,'paddingTop')
						-$dom_cssnum(node,'paddingBottom')
						-$dom_cssnum(node,'borderTopWidth')
						-$dom_cssnum(node,'borderBottomWidth')
					);
			}
		}
		return val;
	}
	function $dom_left(node,value){
		if(value!=undefined){
			$dom_css(node,'left',value);
			return this;
		}
		return $dom_cssnum(node,'left');
	}
	function $dom_top(node,value){
		if(value!=undefined){
			$dom_css(node,'top',value);
			return this;
		}
		return $dom_cssnum(node,'top');
	}
	function $dom_width(node,value){
		if(value!=undefined){
			$dom_css(node,'width',value);
			return this;
		}
		return $dom_cssnum(node,'width')
			||(node.offsetWidth
				-$dom_cssnum(node,'paddingLeft')
				-$dom_cssnum(node,'paddingRight')
				-$dom_cssnum(node,'borderLeft')
				-$dom_cssnum(node,'borderRight')
			);
	}
	function $dom_height(node,value){
		if(value!=undefined){
			$dom_css(node,'height',value);
			return this;
		}
		return $dom_cssnum(node,'height')
			||(node.offsetHeight
				-$dom_cssnum(node,'paddingTop')
				-$dom_cssnum(node,'paddingBottom')
				-$dom_cssnum(node,'borderTop')
				-$dom_cssnum(node,'borderBottom')
			);
	}
	function $dom_offsetLeft(node){
		var left=node.offsetLeft,
			pnode=node.offsetParent;
		while(pnode){
			left+=pnode.offsetLeft||0;
			pnode=pnode.offsetParent;
		}
		return left;
	}
	function $dom_offsetTop(node){
		var top=node.offsetTop,
			pnode=node.offsetParent;
		while(pnode){
			top+=pnode.offsetTop||0;
			pnode=pnode.offsetParent;
		}
		return top;
	}

	function $scrollTop(){
		return $DOC.documentElement.scrollTop||$DOC.body.scrollTop;
	}
	function $scrollLeft(){
		return $DOC.documentElement.scrollLeft||$DOC.body.scrollLeft;
	}
	function $scrollWidth(){
		return $DOC.documentElement.scrollWidth||$DOC.body.scrollWidth;
	}
	function $scrollHeight(){
		return $DOC.documentElement.scrollHeight||$DOC.body.scrollHeight;
	}
	function $dom_opacity(node,opacity){
		if($bom_browser.ie){
			if(typeof opacity=='undefined'){
				var filter=$dom_css(node,'filter');
				if(filter){
					return +filter.match(/(\d+)/)[0]/100;
				}
				return 1;
			}
			node.style.filter='Alpha(opacity='+opacity*100+')';
		}else{
			if(typeof opacity=='undefined'){
				opacity=+$dom_css(node,'opacity');
				return opacity>-1?opacity:1;
			}
			node.style.opacity=opacity;
		}
		return this;
	}
	function $dom_html(node,html){
	
		var type=typeof html,
			_html='';
		if(type=='undefined'){
			return node.innerHTML;
		}else if(type=='function'){
			_html=html();
		}else if(type=='object'){
			$object_each(html,function(){
				_html+=this;
			});
		}else{
			_html=html;
		}
		if(node.nodeName=='SELECT'&&type!='undefined'&&$bom_browser.ie){
			var s=document.createElement('span');
			s.innerHTML='<select>'+_html+'</select>';
			node.innerHTML='';
			$object_each($dom_g('option',s),function(){
				node.appendChild(this);
			});
		}else{
			node.innerHTML=_html;
		}
		return this;
	}
	function $dom_show(node){
		node.style.display='block';
		return this;
	}
	function $dom_hide(node){
		node.style.display='none';
		return this;
	}
	function $dom_val(node,val){
		if(val==undefined)return node.value.replace(/^\s+|\s+$/g,'');
		node.value=val;
		return this;
	}
	function $dom_tag(node,nodeName){
		if(typeof nodeName!='undefined'){
			return nodeName==node.nodeName;
		}
		return node.nodeName;
	}
	function $dom_child(node,index){
		var child = [],
			i=0,
			ol = node.childNodes;
		while(ol[i]){
			ol[i].nodeType==1 && child.push(ol[i]);
			i++;
		}
		if(index>-1){
			child= child[index];
		}else if(index<0){
			child= child[child.length+index];
		}
		return child;
	}
	function $dom_parent(node,selector){
		if(selector==undefined){
			return node.parentNode;
		}else if(selector>0){
			selector=+selector+1;
			while(index--){
				node=node.parentNode;
			}
		}else{
			selector=selector.match(/^(?:#([\w\-]+))?\s*(?:(\w+))?(?:.([\w\-]+))?(?:\[(.+)\])?$/);
			if(selector){
				var id=selector[1],
					tag=selector[2],
					cls=selector[3],
					attr=selector[4];
				tag=tag&&tag.toUpperCase();
				attr=attr&&attr.split('=');
			}else{
				return null;
			}
			
			if(id){
				return $dom_g(id);
			}else{
				while(node=node.parentNode){
					if(
						(!cls||cls&&$dom_hcls(node,cls))
						&&(!tag||node.nodeName==tag)
						&&(!attr||$dom_attr(node,attr[0])==attr[1])
					){
						return node;
					}
				}	
			}
		}
		return null;
	}
	function $dom_prev(node){
		while(node=node.previousSibling){
			if(node.nodeType==1){
				return node;
			}
		}
	}
	function $dom_next(node){
		while(node=node.nextSibling){
			if(node.nodeType==1){
				return node;
			}
		}
	}
	function $dom_sibling(node,selector){
		var parent=node.parentNode,
			_node,
			nodes=selector?$dom_g(selector,node.parentNode):node.parentNode.childNodes,
			re=[],
			i=0;
		while(_node=nodes[i++]){
			if(_node.parentNode==parent&&node!=_node&&_node.nodeType==1)re.push(_node);
		}
		return re;
	}
	function $dom_append(node,newNode,index){
		if(typeof newNode=='string'){
			newNode=$dom_node(newNode);
		}
		if(index==undefined){
			node.appendChild(newNode);
			return this;
		}
		var child=node.childNodes;
		if(!$bom_browser.ie){
			var _child=[];
			for(var i=0,lg=child.length;i<lg;i++){
				if(child[i].nodeType==1)_child.push(child[i]);
			}
			child=_child;
		}
		if(index>-1){
			child= child[index];
		}else if(index<0){
			child= child[child.length+index+1]?child[child.length+index+1]:child[0];
		}
		if(child){
			child.parentNode.insertBefore(newNode,child);
		}else{
			node.appendChild(newNode);
		}
		return this;
	}
	function $dom_insert(node,newNode,flag){
		if(typeof newNode=='string'){
			newNode=$dom_node(newNode);
		}
		if(flag){
			while(node.nextSibling){
				node=node.nextSibling;
				if(node.nodeType==1){
					node.parentNode.insertBefore(newNode,node);
					return this;
				}
			}
			node.parentNode.appendChild(newNode);
		}else{
			node.parentNode.insertBefore(newNode,node);
		}
		return this;
	}
	function $dom_remove(node){
		node.parentNode.removeChild(node);
		return this;
	}
	function $dom_clone(node,flag){
		node=node.cloneNode(flag);
		return node;
	}
	function $dom_replace(node,newNode){
		if(typeof newNode=='string'){
			newNode=$dom_node(newNode);
		}
		node.parentNode.replaceChild(newNode,node);
		return this;
	}
	function $string_encodeHTML(str){
		return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
	}
	function $string_decodeHTML(str){
		return str.replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&amp;/g,'&');
	}
	function $string_encodeURL(str){
		return str
			.replace(/%/g,'%25')
			.replace(/ /g,'%20')
			.replace(/#/g,'%23')
			.replace(/&/g,'%26')
			.replace(/=/g,'%3D')
			.replace(/\//g,'%2F')
			.replace(/\?/g,'%3F')
			.replace(/\+/g,'%2B');
	}
	function $string_tirm(str){
		return str.replace(/^\s+|\s+$/g,'');
	}
	function $request_post(url,callback,data){
		var xmlhttp=new $XHR();
		xmlhttp.open('post',url,true);
		xmlhttp.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
		xmlhttp.onreadystatechange=function(){
			if(xmlhttp.readyState==4){
				if(xmlhttp.status==200){
					callback&&callback(xmlhttp.responseText);
				}else{
					callback&&callback(null);
				}
			}
		};
		xmlhttp.send(typeof data=='object'?$object_toQuery(data):data);
		return xmlhttp;
	}
	function $request_get(url,callback,data){
		var xmlhttp=new  $XHR();
		
		if(data)url+='?'+(typeof data=='object'?$object_toQuery(data):data);
		xmlhttp.open('get',url,true);
		xmlhttp.onreadystatechange=function(){
			if(xmlhttp.readyState==4){
				if(xmlhttp.status==200){
					callback&&callback(xmlhttp.responseText);
				}else{
					callback&&callback(null);
				}
			}
		};
		xmlhttp.send(null);
		return xmlhttp;
	}
	function $request_img(url,callback){
		var img = new Image();
		img.src = url;
		if(img.complete){
			return callback&&callback.call(img,img);
		}
		img.onload = function () {
			callback&&callback.call(img,img);
		};
		return this;
	}
	function $request_js(url,callback,data,charset){
		var s=$DOC.createElement('script');
		if(data)url+='?'+(typeof data=='object'?$object_toQuery(data):data);
		s.src=url;
		charset&&(s.charset=charset);
		$HEAD.appendChild(s);
		if(s.readyState){
			s.onreadystatechange=function(){
				if(s.readyState=='loaded'||s.readyState=='complete'){
					callback&&callback();
					$HEAD.removeChild(s);
				}
			};
		}else{
			s.onload=function(){
				callback&&callback();
				$HEAD.removeChild(s);
			};
		}
		return this;
	}
	function $request_css(arg1){
		if(typeof arg1=='object')arg1=arg1.join('');
		if(/{[\w\W]+?}/.test(arg1)){//cssText
			var s=$DOC.createElement('style');
			s.type='text/css';
			s.styleSheet&&(s.styleSheet.cssText=arg1)||s.appendChild($DOC.createTextNode(arg1));	
		}else{
			var s=$DOC.createElement('link');
			s.rel='stylesheet';
			s.href=arg1;
		}
		$HEAD.appendChild(s);
		return this;
	}
	function $object_toJson(obj){
		switch(typeof obj){
			case 'object':
				if(obj==null){
					return obj;
				}
				var E,_json=[];
				if(Object.prototype.toString.apply(obj) == '[object Array]'){
					for(var e=0,L=obj.length;e<L;e++){
						_json[e]=arguments.callee(obj[e]);
					}
					return '['+_json.join(',')+']';
				}
				for(e in obj){
					_json.push('"'+e+'":'+arguments.callee(obj[e]));
				}
				return '{'+_json.join(',')+'}';
			case 'function':
				obj=''+obj;
			case 'string':
				return '"'+obj.replace(/"/g,'\\"')+'"';
			case 'number':
			case 'boolean':
			case 'undefined':
				return obj;
		}    
		return obj;
	}
	function $object_each(obj,fn){
		if($isArray(obj)){
			for(var i=0,lg=obj.length;i<lg;i++){
				fn.call(obj[i],i);
			}
		}else{
			for(var i in obj){
				fn.call(obj[i],i);
			}
		}
		return this;
	}
	function $object_toQuery(obj,t){
		var query=[];
		if(typeof obj=='object'){
			for(var E in obj){
				if(/^e_/.test(E)){
					query.push(E.substr(2)+'='+$string_encodeURL(obj[E]));
				}else{
					query.push(E+'='+obj[E]);
				}
			}
		}	
		if(t)query.push('t='+(+new Date));
		return query.join('&');
	}
	function $isArray(obj){
		return {}.toString.call(obj)=='[object Array]';
	}
	function $isNode(obj){
		return typeof obj=='object'&&obj.nodeType === 1;
	};
	function $ui_anime(node){
		var self=this,
			timer,
			lock_run=0,//锁定动画
			hasRuning=0,//是否正在运行
			call_stop,//停止动画回调
			call_before,//开始时回调
			call_runing,//运行时回调
			call_after,//完成后回调
			call_done,
			quequ=[],
			quequIndex=0,
			loop=0,//执行次数
			loopQuequ=[],
			loopIndex=0,
			api={
				isStop:function(){
					return !hasRuning;
				},
				stop:function(){
					_stop();
					return self;
				},
				run:function(index){
					if(_stop()){
						if(typeof index=='number'){
							loop=0;
							quequIndex=Math.min(index,quequ.length-1);
						}else{
							quequIndex=0;
						}
						_run.call(self,quequ[quequIndex]);
					}
					return self;
				},
				loop:function(index,_quequ,_done){
					if(_stop()){
						if(typeof index=='number'&&index>0){
							loop=index;
						}else{
							loop=99999;
						}
						loopIndex=0;
						loopQuequ=(function(){
							var q=[];
							if(typeof _quequ=='object'){
								for(var i=0,lg=_quequ.length;i<lg;i++){
									q[i]=quequ[_quequ[i]];
								}
							}else{
								for(var i=0,lg=quequ.length;i<lg;i++){
									q[i]=quequ[i];
								}
							}
							return q;
						})();
						call_done=_done;
						if(typeof _quequ=='function'){
							call_done=_quequ;
						}
						_run.call(self,loopQuequ[loopIndex]);
					}
					
					return self;
				},
				self:function(){
					return self;
				}
				
			};
		function init(option){
			if(!_stop())return api;
			if(typeof option=='object'){
				loop=0;
				quequIndex=0;
				if(option.length){
					quequ=option;
				}else{
					quequ=[option];
				}
			}
			
			timer=setTimeout(function(){
				_run.call(self,quequ[quequIndex]);
			},0);
			return api;
		}
		function _stop(){
			if(lock_run)return 0;
			clearTimeout(timer);
			if(hasRuning){
				hasRuning=0;
				if(call_stop)call_stop.call(self);
			}
			return 1;
		}
		function _run(option){
			call_before=option.before;
			call_runing=option.runing;
			call_stop=typeof option.stop=='function'?option.stop:0;
			call_after=option.after;
			lock_run=option.stop=='lock';//是否允许停止
			hasRuning=1;
			if(call_before)call_before.call(this);
			
			var ns=node.style,
				mc=Math.ceil,
				tp=$EASING[option.type||'Both'],
				xc=0,//x方向改变量
				yc=0,//y方向改变量
				wc=0,//宽度改变量
				ws=0,//宽度改变比例
				hc=0,//高度改变量
				hs=0,//高度改变比例
				o0=0,//初始透明度
				oc=0,//透明度改变
				mx=0,//移动x标志
				my=0,//移动x标志
				rw=0,//改变宽度标志
				rh=0,//改变高度标志
				co=0,//改变透明度标志
				x0,//left初始值
				y0,//top初始值
				w0,//宽度初始值
				h0,//高度初始值
				//run,//动画核心函数
				opa0,
				opac,
				s0=0,//当前步数
				s1=mc((option.t||1000)/16),//总步数,普通人眼能看到1/24秒,window反应时钟16ms，这里取32ms
				end;
			if($bom_browser.ie&&$bom_browser.ie<8){
				$dom_css(node,'zoom',1);
			}
			if(typeof option.w!='undefined'){
				rw=1;
				w0=$dom_width(node);
				if(typeof option.w=='number'){//数字参数，则为目标，字符串则为增量
					wc=option.w-w0;
				}else{
					wc=+option.w;
				}
				if(option.ws){
					x0=$dom_left(node);
					ws=option.ws;
				}
			}
			if(typeof option.h!='undefined'){
				rh=1;
				h0=$dom_height(node);
				if(typeof option.h=='number'){
					hc=option.h-h0;
				}else{
					hc=+option.h;
				}
				if(option.hs){
					y0=$dom_top(node);
					hs=option.hs;
				}
			}
			if(typeof option.x!='undefined'){
				mx=1;
				ws=0;
				x0=$dom_left(node);
				if(typeof option.x=='number'){
					xc=option.x-x0;
				}else{
					xc=+option.x;
				}
			}
			if(typeof option.y!='undefined'){
				my=1;
				hs=0;
				y0=$dom_top(node);
				if(typeof option.y=='number'){
					yc=option.y-y0;
				}else{
					yc=+option.y;
				}
			}
			if(option.o>=0){
				co=1;
				opa0=$dom_opacity(node);
				if(typeof option.o=='number'){
					opac=option.o-opa0;
				}else{
					opac=+option.o;
				}
			}
			if(mx||my||ws||hs){
				if($dom_css(node,'position')=='static'){
					ns.position='relative';
				}
				if($bom_browser.ie&&$bom_browser.ie<7&&(rw||rh)){
					ns.overflow='hidden';
				}
			}
			function _doing(){
				if(call_runing)call_runing();
				if(s0<s1){ 
					if(mx){
						ns.left=mc(tp(s0,x0,xc,s1))+'px';
					}
					if(rw){
						var w=mc(tp(s0,w0,wc,s1));
						ns.width = w+'px';
						if(ws){
							ns.left=x0+(-ws)*(w-w0)+'px';
						}
					}
					if(my){
						ns.top=mc(tp(s0,y0,yc,s1))+'px';
					}
					if(rh){
						var h=mc(tp(s0,h0,hc,s1));
						ns.height = h+'px';
						if(hs){
							ns.top=y0+(-hs)*(h-h0)+'px';
						}
					}
					if(co){
						$dom_opacity(node,tp(s0,opa0,opac,s1));
					}
					s0++;
					timer=setTimeout(_doing,15.6); 
				}else{
				
					// 最终修正误差
					if(mx){
						ns.left=x0+xc+'px';
					}
					if(rw){
						ns.width = w0+wc+'px';
						if(ws)ns.left=x0+(-ws)*(wc)+'px';
					}
					if(my){
						ns.top=y0+yc+'px';
					}
					if(rh){
						ns.height = h0+hc+'px';
						if(hs){
							ns.top=y0+(-hs)*(hc)+'px';
						}
					}
					if(co){
						$dom_opacity(node,opa0+opac);
					}
					
					clearTimeout(timer);
					lock_run=0;
					hasRuning=0;
					if(call_after)call_after.call(self);
					if(loop){
						loopIndex++;
						
						if(loopIndex<loopQuequ.length){//正常情况，队列还没有执行完
							
						}else if(loop>1){//一次队列完成，执行下一次
							loopIndex=0;
							loop--;
						}else{//结束，队列和循环皆空
							if(call_done)call_done.call(self);
							return;
						}
						_run.call(self,loopQuequ[loopIndex]);
					}else{
						if(call_done)call_done.call(self);
					}
				}
			}
			timer=setTimeout(_doing,15.6); //启动动画
		}
		return init;
		
	}

	$Jlazy.browser=$bom_browser;

	$Jlazy.cookie=$bom_cookie;
	$Jlazy.docWidth=$bom_docWidth;
	$Jlazy.docHeight=$bom_docHeight;

	$Jlazy.about={
		version:'2.0',
		updata:'2011.4.14'
	};
	$Jlazy.method=function(name,func){
		$Jlazy[name]=func;
		return this;
	};
	$Jlazy.extend=function(name,func){
		$_Jlazy.prototype[name]=func;
		return this;
	};
	$Jlazy.conflict=function(){
		$WIN[name]=$Gname;
		return $Jlazy;
	};
	$_Jlazy.prototype.each=function(func){
		if(this.nodes){
			var i=0;
			while(this.nodes[i]){
				func.call($Jlazy(this.nodes[i]),i);
				i++;
			}
		}else if(this.node){
			func.call(this,0);
		}
		return this;
	};
	$_Jlazy.prototype.eq=function(i){
		if(i<0)i=this.nodes.length+i;
		return $Jlazy(this.nodes[i]);
	};
	

	$_Jlazy.prototype.on=function(type,func,who){
		var result=$event_bind.call(this,this.node,type,func,who||$Jlazy(this.node));
		if(this.nodes&&result==this){
			var i=1;
			while(this.nodes[i]){
				$event_bind.call(this,this.nodes[i],type,func,who||this.eq(i));
				i++;
			}
			return this;
		}else{
			return result;
		}
	};
	$_Jlazy.prototype.un=function(type,func,who){
		var result=$event_unbind.call(this,this.node,type,func,who||$Jlazy(this.node));
		if(this.nodes&&result==this){
			var i=1;
			while(this.nodes[i]){
				$event_unbind.call(this,this.nodes[i],type,func,who||this.eq(i));
				i++;
			}
			return this;
		}else{
			return result;
		}
	};
	$_Jlazy.prototype.click=function(func,who){
		var result=$event_bind.call(this,this.node,'click',func,who||$Jlazy(this.node));
		if(this.nodes&&result==this){
			var i=1;
			while(this.nodes[i]){
				$event_bind.call(this,this.nodes[i],'click',func,who||this.eq(i));
				i++;
			}
			return this;
		}else{
			return result;
		}
	};
	
	$_Jlazy.prototype.hover=function(hover,out,who){
		var node,
			self=this;
		if(this.nodes){
		
			var i=0;
			while(node=this.nodes[i]){
				~function(_who){
					var node=_who.node;
					$event_bind(node,'mouseover',function(evt){
						if(evt.fromTarget&&!$dom_contains(node,evt.fromTarget))hover.call(who||_who,evt);
					},who||_who);
					$event_bind(node,'mouseout',function(evt){
						if(!$dom_contains(node,evt.toTarget))out.call(who||_who,evt);
					},who||_who);
				}(this.eq(i));
				i++;
			}
		}else{
			node=this.node;
			$event_bind(node,'mouseover',function(evt){
				if(evt.fromTarget&&!$dom_contains(node,evt.fromTarget))hover.call(who||self,evt);
			},who||self);
			$event_bind(node,'mouseout',function(evt){
				if(!$dom_contains(node,evt.toTarget))out.call(who||self,evt);
			},who||self);
		}
		return this;
	};
	
	
	$Jlazy.g=$dom_g;
	$Jlazy.node=$dom_node;
	$_Jlazy.prototype.find=function(selector){
		return $Jlazy(selector,this.node);
	};
	$_Jlazy.prototype.cls=function(cls1,cls2){
		return $box.call(this,$dom_cls,cls1,cls2);
	};
	$_Jlazy.prototype.css=function(name,value){
		return $box.call(this,$dom_css,name,value);
	};
	
	$_Jlazy.prototype.attr=function(name,value){
		return $box.call(this,$dom_attr,name,value);
	};
	$_Jlazy.prototype.contains=function(cnode){
		return $dom_contains(this.node,cnode);
	};
	$_Jlazy.prototype.cssnum=function(name){
		return $dom_cssnum(this.node,name);
	};
	$_Jlazy.prototype.left=function(value){
		return $box.call(this,$dom_left,value);
	};
	$_Jlazy.prototype.top=function(value){
		return $box.call(this,$dom_top,value);
	};
	$_Jlazy.prototype.width=function(value){
		return $box.call(this,$dom_width,value);
	};
	$_Jlazy.prototype.height=function(value){
		return $box.call(this,$dom_height,value);
	};
	$_Jlazy.prototype.offsetLeft=function(){
		return $dom_offsetLeft(this.node);
	};
	$_Jlazy.prototype.offsetTop=function(){
		return $dom_offsetTop(this.node);
	};
	$_Jlazy.prototype.offsetWidth=function(){
		return this.node.offsetWidth;
	};
	$_Jlazy.prototype.offsetHeight=function(){
		return this.node.offsetHeight;
	};
	$Jlazy.scrollLeft=function(){
		return $scrollLeft();
	};
	$Jlazy.scrollTop=function(){
		return $scrollTop();
	};
	$Jlazy.scrollWidth=function(){
		return $scrollWidth();
	};
	$Jlazy.scrollHeight=function(){
		return $scrollHeight();
	};
	$_Jlazy.prototype.opacity=function(opacity){
		return $box.call(this,$dom_opacity,opacity);
	};
	$_Jlazy.prototype.html=function(html){
		return $box.call(this,$dom_html,html);
	};
	$_Jlazy.prototype.show=function(){
		return $box.call(this,$dom_show);
	};
	$_Jlazy.prototype.hide=function(){
		return $box.call(this,$dom_hide);
	};
	$_Jlazy.prototype.val=function(value){
		return $box.call(this,$dom_val,value);
	};
	$_Jlazy.prototype.tag=function(nodeName){
		return $dom_tag(this.node,nodeName);
	};
	
	$_Jlazy.prototype.child=function(index){
		return $Jlazy($dom_child(this.node,index));
	};
	$_Jlazy.prototype.parent=function(index){
		return $Jlazy($dom_parent(this.node,index));
	};
	$_Jlazy.prototype.prev=function(){
		return $Jlazy($dom_prev(this.node));
	};
	$_Jlazy.prototype.next=function(){
		return $Jlazy($dom_next(this.node));
	};
	$_Jlazy.prototype.sibling=function(selector){
		return $Jlazy($dom_sibling(this.node,selector));
	};
	$_Jlazy.prototype.append=function(newNode,index){
		return $box.call(this,$dom_append,newNode,index);
	};
	$_Jlazy.prototype.insert=function(newNode,flag){
		return $box.call(this,$dom_insert,newNode,flag);
	};
	$_Jlazy.prototype.remove=function(){
		return $box.call(this,$dom_remove);
	};
	$_Jlazy.prototype.clone=function(flag){
		return $Jlazy($dom_clone(this.node,flag));
	};
	$_Jlazy.prototype.replace=function(newNode){
		return $box.call(this,$dom_remove,newNode);
	};

	$Jlazy.Class=function(name,pro){
		if(typeof name=='string'){
			if(typeof pro=='function')pro=pro();
			$Jlazy[name]=$Class.extend(pro);
		}else{
			if(typeof name=='function')name=name();
			return $Class.extend(name);
		}
	};
	$Jlazy.inherit=function(name,supClass,pro){
		if(typeof pro=='function')pro=pro();
		$Jlazy[name]=supClass.extend(pro);
	};
	$Jlazy.block=function(obj){
		if(typeof obj=='function')obj=obj();
		obj.init();
	};
	$Jlazy.widget=function(name,func){
		$Jlazy[name]=func();
	};
	$Jlazy.fixed=function(){
		$event_ready(function(){
			if($isIE6 && $dom_css($dom_g('body')[0],'backgroundAttachment') !== 'fixed'){
				$dom_css($dom_g('html')[0],{
					backgroundAttachment: 'fixed'
				});	
			}
		});
		return function(node,fixY){
			node=$dom_g(node);
			$dom_css(node,'position:absolute');
			
			node.style.setExpression('top', 'eval(document.documentElement.scrollTop)+'+fixY+'+"px"');
		};
	}();
	$Jlazy.unfixed=function(node){
		node.style.removeExpression('top');
	};



	$Jlazy.encodeHTML=$string_encodeHTML;
	$Jlazy.decodeHTML=$string_decodeHTML;
	$Jlazy.encodeURL=$string_encodeURL;
	$Jlazy.tirm=$string_tirm;
	$Jlazy.parseJson=function(json){
		try{
			return eval('('+json+')');
		}catch(e){
			return null;
		}
	};

	$Jlazy.post=$request_post;
	$Jlazy.get=$request_get;
	$Jlazy.img=$request_img;
	$Jlazy.js=$request_js;
	$Jlazy.css=$request_css;

	$Jlazy.toJson=$object_toJson;
	$Jlazy.each=$object_each;
	$Jlazy.toQuery=$object_toQuery;


	$Jlazy.isIE6=$isIE6;
	$Jlazy.isArray=$isArray;
	$Jlazy.isNode=$isNode;

	$_Jlazy.prototype.anime=function(option){
		
		if(!this.node.___ANIMEID){
			var pid=this.node.___ANIMEID=$PID;
				$PID++;
			$ANIMEQUEQU[pid]=$ui_anime.call(this,this.node);
			
		}
		return $ANIMEQUEQU[this.node.___ANIMEID](option);
	};

	$_Jlazy.prototype.drag=function(option){
		if(!this.node.___DRAGID){
			var pid=this.node.___DRAGID=$PID;
				$PID++;
			//$DRAGQUEQU[pid]=$ui_drag.call(this,this.node);
			option=option||{};
			option.node=this.node;
			$DRAGQUEQU[pid]=new $ui_Drag(option);
		}
		return $DRAGQUEQU[this.node.___DRAGID];
	};



	$WIN[name]=$Jlazy;
}('J')