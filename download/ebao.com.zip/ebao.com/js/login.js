<?
$inc('widget/Jw_masklayer.js')
$inc('widget/Jw_dialog.js')
$inc('widget/Jw_form.js')
$inc('widget/Pw_login.js')
$inc('widget/Pw_weibo.js')
$inc('public/page.js')
?>
J(function(){
	var form1=J.Form('#form1').skin({
		name:'default',
		type:'tips,erro,null',
		data:{
			email:['邮箱的格式为example@example.com','请填写正确格式的邮箱！','请填写常用的邮箱！'],
			code:['','','不能为空！'],
			password:['密码由6-16位字母，数字组成','填写正确的密码','不能为空！']
		}
	});
});
    