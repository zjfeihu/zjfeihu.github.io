<?
$inc('widget/Jw_masklayer.js')
$inc('widget/Jw_dialog.js')
$inc('widget/Pw_login.js')
$inc('widget/Jw_form.js')
$inc('widget/Pw_weibo.js')
$inc('public/page.js')
?>
J(function(){
	var form1=J.Form('#form1').skin({
		name:'class',
		type:'tips,null,erro',
		data:{
			'default':['提示','此项不能为空','格式错误提示']
		}
	});
	if(J.g('#firstJob')){
		J('#firstJob').on('change',function(){
			var jobType1='';
			J.post('group.php',function(result){
				if(result){
					J('select[fid=secondJob]').html(result);
					form1.doTest(J('select[fid=thirdJob]').html('<option value="">请选择工种</option>'));
				}
			},{
				action:'getJobList',
				selecId:'secondJob',
				jobId:this.val()
			});
		});
		J('select[fid=secondJob]').each(function(){
			var self=this;
			self.node.onchange=function(){
				J.post('group.php',function(result){
					if(result){
						self.next().html(result);
						form1.doTest(self.next());
					}
				},{
					action:'getJobList',
					selecId:'thirdJob',
					jobId:self.val()
				});
			};
		});
	}
	if(J.g('#chkMedical')){
		J('#acPrice').on('change',function(){
			var price = J('#acPrice').val();
			switch(true){
			case price <= 15:
				var html = '<option value="">请选择金额</option><option value="1">1万</option>';
				break;
			case price > 15 && price <= 25:
				var html = '<option value="">请选择金额</option><option value="1">1万</option><option value="2">2万</option>';
				break;
			case price > 25 && price <= 35:
				var html = '<option value="">请选择金额</option><option value="1">1万</option><option value="2">2万</option><option value="3">3万</option>';
				break;
			case price > 35 && price <= 45:
				var html = '<option value="">请选择金额</option><option value="1">1万</option><option value="2">2万</option><option value="3">3万</option><option value="4">4万</option>';
				break;
			case price > 45:
				var html = '<option value="">请选择金额</option><option value="1">1万</option><option value="2">2万</option><option value="3">3万</option><option value="4">4万</option><option value="5">5万</option>';
				break;
			}
			J('#medical').html(html);

		
		});
		J('#chkMedical').click(function(){
			if(this.attr('checked')){
				J('#medical').attr('disabled',false).attr('notNull',1).attr('pid','default');
				J('#loRatio').attr('disabled',false);
			}else{
				var fb=J('#medical').attr('disabled',true).attr('notNull',0).parent('.formbox');
				if(fb.node)fb.cls('-isErro,isPass,isNull,isTips');
				J('#loRatio').attr('disabled',true);
			}
		});
		J('#chkBenefit').click(function(){
			if(this.attr('checked')){//benefit
				J('#benefit').attr('disabled',false).attr('notNull',1).attr('pid','default');
			
			}else{
				var fb=J('#benefit').attr('disabled',true).attr('notNull',0).parent('.formbox');
				if(fb.node)fb.cls('-isErro,isPass,isNull,isTips');
			
			}
		
		});
	
	}

});