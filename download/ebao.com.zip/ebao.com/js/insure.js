<?
$inc('widget/Jw_masklayer.js')
$inc('widget/Jw_dialog.js')
$inc('widget/Jw_form.js')
$inc('widget/Pw_login.js')
$inc('widget/Jw_calendar.js')
$inc('widget/Pw_weibo.js')
$inc('public/page.js')
$inc('widget/Pw_numset.js')
?>
J(function(){
	if(!J.g('#form1'))return;
	var form1=J.Form('#form1').skin({
		name:'class',
		type:'tips,erro,null',
		data:{
			name:['请填写您的真实姓名，应与身份证相符，以便投保及理赔','','姓名不能为空'],
			idnumber:['','只能为数字','不能为空！'],
			birth:['','填写正确的出生日期','不能为空！'],
			phone:['建议填写您的手机号码，以便接收保单信息','','不能为空！'],
			email:['建议您填写电子邮箱，以便接受相关通知。','邮箱格式不正确','不能为空！'],
			address:['建议您填写您的通讯地址，方便我们邮寄纸质保单。','','不能为空！'],
			start_date:['','起保日期必须是昨天之后','为必填项'],
			owner:['','','至少需要一个投保人']
			
		}
		
	
	}).addTest('birth',function(Jtaget){
		var date=Jtaget.val().split('-'),
			date=new Date(date[0],date[1]-1,date[2]),
			date2=new Date,
			y=date2.getFullYear(),
			m=date2.getMonth()+1,
			d=date2.getDate();
		if(+new Date(y,m-1,d)>=+date){
			return 1;
		}
		return 0;
	}).addTest('start_date',function(Jtaget){
		var date=Jtaget.val().split('-'),
			date=new Date(date[0],date[1]-1,date[2]),
			date2=new Date,
			y=date2.getFullYear(),
			m=date2.getMonth()+1,
			d=date2.getDate();
		if(+new Date(y,m-1,d)<=+date){
			return 1;
		}
		return 0;
	});
	if(J.g('#owner')){
		var ilg=J('b.write-number').nodes.length;
		function add(){
			if(ilg==1){//第一次添加
				J('#owner').attr('notNull',0).parent().cls('-isTips,isPass,isErro,isNull');
			}
			ilg++;
			J('#moreform').append('<ul class="write-tab">\
		<h3 class="write-tab-title">第<b class="write-number">'+(ilg)+'</b>被保险人：<em><a class="del-person fr"  href="javascript:;" jbtn="delete">删除</a></em></h3>\
		<li>\
			<label class="tl"><span class="red">*</span>您是被保人的：</label>\
			<select class="accept-relative" name="accept[{i}][relative]">\
				<option value="2">配偶</option>\
				<option value="3">子女</option>\
				<option value="4">父母</option>\
				<option value="5">其他</option>\
			</select>\
		</li>\
		<li>\
			<label class="tl"><span class="red">*</span>被保险人姓名：</label>\
			<input class="write-input accept-name"  maxlength="18" name="accept[{i}][name]" pid="name" notNull="1" />\
		</li>\
		<li>\
			<label class="tl">姓别：</label>\
			<label><input type="radio" checked class="write-radio accept-gender" name="accept[{i}][gender]" value="1"/>&nbsp;男&nbsp;&nbsp;&nbsp;&nbsp;</label>\
			<label><input type="radio" class="write-radio accept-gender" name="accept[{i}][gender]" value="0">&nbsp;女</label>\
		</li>\
		<li>\
			<label class="tl">证件类型：</label>\
			<select class="accept-idtype" name="accept[{i}][idtype]" type="select">\
				<option selected="selected" value="1">身份证</option>\
				<option value="2">护照</option>\
				<option value="3">出生证</option>\
				<option value="4">其它</option>\
			</select>\
		</li>\
		<li>\
			<label class="tl"><span class="red">*</span>证件号码：</label>\
			<input class="write-input accept-idnumber" maxlength="18" name="accept[{i}][idnumber]" pid="idnumber" notNull="1"/>\
		</li>\
		<li>\
			<label class="tl"><span class="red">*</span>出生日期：</label>\
			<input type="calendar" readonly class="write-input accept-birth" name="accept[{i}][birth]" fid="birth" pid="birth" notNull="1"/>\
		</li>\
		<li>\
			<label class="tl">联系电话：</label>\
			<input class="write-input accept-phone" name="accept[{i}][phone]" maxlength="18">\
		</li>\
		<li>\
			<a jbtn="addPerson" class="add-person fr" href="javascript:;">添加被保人</a>\
		</li>\
	</ul>'.replace(/\{i\}/g,ilg-2));
			
		}
		function remove(Jtarget){
			ilg--;
			var tb=Jtarget.parent('.write-tab');
			if(tb.find('a[jbtn=addPerson]').node){//最后一个节点
				if(ilg==1){
					J('#moreform h3.write-tab-title').eq(0).append(tb.find('a[jbtn=addPerson]').node);
					J('#owner').attr('notNull',1);
				}else{
					J('#moreform ul.write-tab').eq(-2).append(tb.find('a[jbtn=addPerson]').parent('li').node);
				}
				tb.remove();
			}else{
				tb.remove();
				J('#moreform .write-number').each(function(i){
					this.html(i+1);
				});
				J.each([
					'relative',
					'name',
					'idtype',
					'idnumber',
					'birth',
					'gender',
					'phone'
				],function(){
					var me=this;
					J('#moreform .accept-'+this).each(function(i){
						this.attr('name','accept['+i+']'+me);
					});
					
				});
			
			}
		
		}
		
		J('#owner').click(function(){
			this.val(this.attr('checked')?1:'');
		});
		J('#moreform').click(function(evt){
			var Jtarget=J(evt.target);
			switch(Jtarget.attr('jbtn')){
				case 'addPerson':
					add();
					Jtarget.remove();
					
					return;
				case 'delete':
					remove(Jtarget);
					return;
			}
		});
	
	}
	if(J.g(".help-a")){
		J(".help-a").each(function(){
			var tooltip=this.attr("tooltip");
			if(tooltip){
			    this.on("mouseover",function(){
					J("div.tooltip[tooltip="+tooltip+"]").css({left:this.offsetLeft()+20,top:this.offsetTop()}).show();
			    }).on("mouseout",function(){
					J("div.tooltip[tooltip="+tooltip+"]").hide();
				});
			}
		});
	}
	
});

J(function(){
	if(J.g('#agreenment')){
		J('#form2').on('submit',function(e){
			if(!J('#agreenment').attr('checked')){
				e.preventDefault();
				alert('请先同意协议！');
			}
		});
	}
});
//xiaojian add 2011-05-13
J(function(){
	if(J.g('#pay-box')){
		var d1=J.Dialog({
			cls:'Pw_box',
			lock:1,
			width:420,
			title:'请确认支付结果',
			content:'<div class="P_box">'
				+'<p class="P_warn"><strong>请您在新打开的页面完成付款！</strong><br />付款完成前请不要关闭此窗口。<br />付款完成后，请根据结果选择：</p>'
			+'</div>'
			+'<p class="bottom"><input jbtn="yes" type="button" class="pbtn" value="付款成功"> <input jbtn="no" type="button" class="pbtn-long" value="付款失败，请重试"></p>',
			yes:function(){
				//alert('付款成功')
				J.get(J('#confirm-pay').attr('data-url'),function(result){
					if(result=J.parseJson(result)&&result.res==1){
						location.href=result.url;
					}else{
						d1.hide();
						d4.show();
					}
				});
			},
			no:function(){
				return 1;
			}
		}),
		d4=J.Dialog({
			cls:'Pw_box',
			title:'系统提示',
			width:200,
			lock:1,
			content:'<div style="padding:8px;text-align:center;font-size:14px;color:red;">支付失败，请重试！</div>'
		
		});
		J('#confirm-pay').click(function(evt){
			var val='';
			J('#pay-box').find('input[type=radio]').each(function(){
				if(this.attr('checked')){
					val=this.val();
				}
			});
			d1.show();
			evt.preventDefault();
			alert(val);//银行的链接接口没写
		});
	}

	if(J.g("#pay-box")){
		var focus=0,
			btn=J('#pay-box .panel-nav').find('li'),
			box=J('#pay-box .insure-panel').find('.insure-tabContent');
		btn.each(function(i){
			this.click(function(){
				if(focus!=i){
					btn.eq(focus).cls('-paycurr');
					box.eq(focus).cls('+hidden');
					btn.eq(i).cls('+paycurr');
					box.eq(i).cls('-hidden');
					focus=i;
				}
			});
		});
	}
});