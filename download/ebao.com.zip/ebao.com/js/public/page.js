<?
$inc('../widget/Pw_search.js')
?>