J(function(){
	var Data={
		titleImg:'css/images/pc/title-',
		title:[//标题
			'您的性别',
			'您的年龄',
			'您的年龄',
			'您的年龄',
			'您的年龄',
			'您的年龄',
			'您的年龄',
			'您的年龄',
			'您的年龄',
			'您的年龄',
			'您的年龄',
			'您的年龄',
			'您的年龄',
			'您的年龄',
			'您的年龄',
			'您的年龄'
		],
		icon:[//图标
			{
				alt:['xx','yy'],
				src:['xb-1.png','xb-2.png']
			},	
			{
				alt:['xx','yy'],
				src:['nianling-1.png','nianling-2.png','nianling-3.png','nianling-4.png','nianling-5.png']
			},	
			{
				alt:['xx','yy'],
				src:['gzxz-1.png','gzxz-2.png']
			},	
			{
				alt:['xx','yy'],
				src:['gzaq-1.png','gzaq-2.png']
			},	
			{
				alt:['xx','yy'],
				src:['yysj-1.png','yysj-2.png','yysj-3.png','yysj-4.png']
			},		
			{
				alt:['xx','yy','','','next'],
				src:['yyhd-1.png','yyhd-2.png','yyhd-3.png','yyhd-4.png','next-go.png']
			},	
			{
				alt:['xx','yy'],
				src:['yszk-1.png','yszk-2.png']
			},
			{
				alt:['xx','yy'],
				src:['hfzk-1.png','hfzk-2.png']
			},	
			{
				alt:['xx','yy','yy','yy','yy','yy','yy','next'],
				src:['znjy-1.png','znjy-2.png','znjy-3.png','znjy-4.png','znjy-5.png','znjy-6.png','znjy-7.png','next-go.png']
			},	
			{
				alt:['xx','yy'],
				src:['lrzk-1.png','lrzk-2.png','lrzk-3.png','lrzk-4.png']
			},	
			{
				alt:['xx','yy'],
				src:['jtnsr-1.png','jtnsr-2.png','jtnsr-3.png','jtnsr-4.png','jtnsr-5.png','jtnsr-6.png']
			},	
			{
				alt:['xx','yy'],
				src:['gfgc-1.png','gfgc-2.png','gfgc-3.png','gfgc-4.png']
			},	
			{
				alt:['xx','yy'],
				src:['sbzk-1.png','sbzk-2.png']
			},	
			{
				alt:['xx','yy'],
				src:['sybx-1.png','sybx-2.png']
			},
			{
				alt:['xx','yy'],
				src:['sybx-1.png','sybx-2.png']
			}
		
		],
		type:[//单选多选，0单选，1多选,2婚姻状况，3结束
			0,0,0,0,0,1,0,2,1,0,0,0,0,3,0,0
		],
		selected:[//选择的数据
			'','','','','','','','','','','','','',''
		],
		show:[]
	
	};

	
	var opc_time=J.browser.ie?1:300;//ie下绝对定位的子层透明度实效
	var done_step=-1,//已完成调查的最终步数
		cur_step=-1,//当前的
		prev_step=-1,//上一步的
		scrollIdx=0;//滚动条的位置标记

	
	setContent();
	bind();
	begin();
	function setContent(){//创建问卷内容
		J('#order').html(function(){
			var ht='',
				icon=Data.icon;
			for(var i=0,lg=icon.length;i<lg;i++){
				ht+='<li>'+(function(){
					var img='';
					J.each(icon[i].src,function(j){
						img+='<img src="css/images/pc/'+this+'" idx="'+(j+1)+'" alt="'+icon[i].alt[j]+'"/>';
					});
					return img;
				})()+'</li>';
			}
			return ht;
		});
	}
	function bind(){
		J('#next').click(function(){
			scroll(++scrollIdx);
		});
		J('#prev').click(function(){
			scroll(--scrollIdx);
		});
		J('#scrollBar li').each(function(i){
			this.click(function(){
				if(this.cls('on')&&cur_step!=i){
					prev_step=cur_step;
					view(i);
				}
			});
		});
	}
	function begin(){
		J('#begin').click(function(){
			J('#index').hide();
			J('#scrollBar-gg').hide();
			J('#titbox').css('visibility','visible');
			J('#scroll').show();
			prev_step=-1;
			cur_step=0;//当前调查的位置
			show(cur_step);
		});
	}
	function show(index){
		if(index!=prev_step){//不是上一步
			if(prev_step!=-1){//存在上一步
				J('#order li').eq(prev_step).anime({
					o:0,
					t:opc_time,
					after:function(){
						J(this.node).hide();
					}
				});
				
			}
			var px=getPx(Data.icon[index].src.length);//获取坐标等相关配置
			J('#order li').eq(index).anime({
				o:1,
				t:opc_time,
				before:function(){
					J(this.node).opacity(0).show();
				},
				after:function(){
					J(this.node).find('img').each(function(i){
						this.css({
							left:px.left+i*(px.size+px.margin)
						}).anime([
							{y:130,t:600,type:'backBoth'},
							{w:px.size-px.csize,ws:0.5,h:px.size-px.csize,hs:0.5,t:300,type:'backOut',
								after:function(){
									J(this.node).css('cursor:pointer').on('mouseover',function(){
										this.anime({w:px.size,ws:0.5,h:px.size,hs:0.5,t:300,type:'backBoth'});
									}).on('mouseout',function(){
										this.anime({w:px.size-px.csize,ws:0.5,h:px.size-px.csize,hs:0.5,t:300,type:'backBoth'});
									}).click(function(){
										if(this.attr('lock')!=1){
											if(Data.selected[index]==''){//未完成调查
												switch(Data.type[index]){
													
													case 0://单选
													case 2://婚姻状况
													case 3://结束
														this.parent().find('img').attr('lock',1);//全部锁定
														Data.selected[index]=this.attr('idx');//设置数据选中
														this.insert('<i class="selected"></i>').sibling('i').css({
															left:px.left+i*(px.size+px.margin)+px.csize-20,
															top:130+px.csize/2
														});
														prev_step=cur_step;//设置为过去
														if(this.attr('idx')==2&&Data.type[index]==2){//未婚，跳过子女
															++cur_step;
														}
														done_step=cur_step;//设置完成步数
														if(Data.type[index]!=3){
															show(++cur_step);//进行下一步
														}else{
															end();
															//alert(J.toJson(Data.selected));
														}
														//alert(done_step);
														break;
													case 1://多选
														if(this.attr('alt')!='next'){//非next按钮
															Data.selected[index]=this.attr('idx');//设置数据选中
															this.attr('selected',1).insert('<i idx="'+this.attr('idx')+'" class="selected"></i>').sibling('i').css({
																left:px.left+i*(px.size+px.margin)+px.csize-20,
																top:130+px.csize/2
															});
														}
														break;
												}
											
											}else{
												switch(Data.type[index]){
													case 0://单选
													case 2://婚姻状况
													case 3://结束
														this.parent().find('img').attr('lock',1).attr('selected',0).sibling('i').each(function(){
															this.remove();
														});//全部锁定
														Data.selected[index]=this.attr('idx');//设置数据选中
														this.insert('<i class="selected"></i>').sibling('i').css({
															left:px.left+i*(px.size+px.margin)+px.csize-20,
															top:130+px.csize/2
														});
														done_step=Math.max(done_step,cur_step);//设置完成步数
														prev_step=cur_step;//设置为过去
														if(Data.type[index]==2){//婚姻问卷
															if(this.attr('idx')==2){//未婚，跳过子女,清空数据
																J('#scrollBar li').eq(index+1).cls('-on');	
																if(Data.selected[index+1]!=''){
																	Data.selected[index+1]='';
																	this.parent('li').next().find('img').attr('selected',0).sibling('i').remove();
																}
																J('#scrollBar li.xon').each(function(i){
																	this.cls('+on').cls('-xon');
																});	
															}else{//从未婚改成已婚
																if(Data.selected[index+1]==''){
																	J('#scrollBar li').each(function(i){
																		if(i>8&&i<done_step+2){
																			this.cls('-on').cls('+xon');
																		}
																	});													
																	if(this.parent('li').next().find('img').top()>0){//使用view
																		view(cur_step=index+1);
																	}else{
																		show(cur_step=index+1);
																	}
																	return;
																}
																
															}
														}
														if(Data.type[index]!=3){
															view(cur_step=done_step+1);//进行下一步
														}
														
														break;
													case 1://多选
														
														if(this.attr('selected')==1){//取消选择
															Data.selected[index]=Data.selected[index].replace(new RegExp(',?'+this.attr('idx')),'');//取消选择
															this.attr('selected',0).sibling('i[idx='+this.attr('idx')+']').remove();
														}else if(this.attr('alt')=='next'){//下一步
															if(Data.selected[index]!=''){//执行下一步
																this.parent().find('img').attr('lock',1);//全部锁定
																done_step=Math.max(done_step,cur_step);//设置完成步数
																prev_step=cur_step;//设置为过去
																if(J('#order li').eq(cur_step+1).find('img').top()>0){
																	J('#scrollBar li.xon').each(function(i){
																		this.cls('+on').cls('-xon');
																	});	
																	view(cur_step=done_step+1);//进行下一步
																	
																}else{
																	show(++cur_step);//进行下一步
																}
															}
														}else{//选择更多的
															Data.selected[index]+=','+this.attr('idx');//设置数据选中
															this.attr('selected',1).insert('<i idx="'+this.attr('idx')+'" class="selected"></i>').sibling('i[idx='+this.attr('idx')+']').css({
																left:px.left+i*(px.size+px.margin)+px.csize-20,
																top:130+px.csize/2
															});
														}
														//alert(Data.selected[index])
														break;
												}
											
												
											}
											
										}
									});
								
								}
							}
						]).loop(1);
					});
					
				}
			});
			J('#titbox img')
				.attr('src',Data.titleImg+(index+1)+'.png')
				.attr('alt',Data.title[index]);

			scroll(index);
			J('#scrollBar li').eq(cur_step=index).cls('+on');	
		}
	}
	function view(index){
		J('#order li').eq(prev_step).anime({
			o:0,
			t:opc_time,
			after:function(){
				J(this.node).hide();
			}
		});
		J('#order li').eq(index).anime({
			o:1,
			t:opc_time,
			before:function(){
				J(this.node).opacity(0).show().find('img').attr('lock',0);
			}
		});	
		J('#titbox img')
				.attr('src',Data.titleImg+(index+1)+'.png')
				.attr('alt',Data.title[index]);
		scroll(index);
		J('#scrollBar li').eq(cur_step=index).cls('+on');	
		
	}
	function getPx(lg){
		switch(lg){
			case 2:
				return{
					size:124,
					csize:30,
					margin:50,
					left:244
				};
			case 4:
				return{
					size:124,
					csize:30,
					margin:20,
					left:112
				};
			case 5:
				return{
					size:124,
					csize:30,
					margin:10,
					left:66
				};
			case 6:
				return{
					size:102,
					csize:30,
					margin:8,
					left:60
				};
			case 7:
				return{
					size:90,
					csize:30,
					margin:8,
					left:40
				};
			case 8:
				return{
					size:94,
					csize:20,
					margin:-4,
					left:20
				};
		}
	
	}
	function scroll(index){
		if(index>0){
			J('#prev').cls('+on');
			if(index<9){
				J('#next').cls('+on');
			}else{
				J('#next').cls('-on');
			}
			
		}else{
			J('#prev').cls('-on');
		}
		
		index=Math.min(Math.max(index,0),9);
		scrollIdx=index;
		J('#scrollBar').anime({
			x:4-135*index,
			t:300,
			type:'backOut',
			stop:'lock'
		});
	}
	function end(){
		J('#scrollBar-gg').show();
		J('#form').show();
		J('#order').hide();
		J('#scroll').hide();
		
		J('#titbox img').attr('src',Data.titleImg+(14+1)+'.png');
		
		J('#form').on('submit',function(evt){
			if(J('#username').val()==''){
				alert('姓名不能为空！');
				evt.preventDefault();
			}else if(J('#tel').val()==''){
				alert('电话不能为空！');
				evt.preventDefault();
			}else if(J('#email').val()==''){
				alert('邮箱不能为空！');
				evt.preventDefault();
			}else if(!/^\w+@\w+(\.\w+)+$/.test(J('#email').val())){
				alert('请输入正确格式的邮箱！');
				evt.preventDefault();
			
			}else{
				alert('发送数据'+J.toJson({
					info:{
						user:J("#username").val(),
						tel:J("#tel").val(),
						email:J("#email").val()
					},
					selected:Data.selected
				}));
			}
		});
	}

});