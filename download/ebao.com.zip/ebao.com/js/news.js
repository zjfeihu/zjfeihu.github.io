<?
$inc('widget/Jw_masklayer.js')
$inc('widget/Jw_dialog.js')
$inc('widget/Pw_login.js')
$inc('widget/Pw_shop.js')
$inc('widget/Pw_weibo.js')
$inc('public/page.js')
?>
J(function(){
	(function(){
		if(J.g("#content")){
			J("#copyUrl").click(function(e){
				var _text=this.attr("href");
			    J.copy(_text);
			    alert("文章网址复制成功，您可以把网址粘贴到其它地方来分享这篇文章");
				e.preventDefault();
			});
			J("#printContent").click(function(e){
				//window.print() ;
				J.printContent(J("#printArea"));
			    e.preventDefault();
			});
		}
	})();
	J.method("printContent",function(printpage){
		var headstr = "<html><head><title></title></head><body>";
		var footstr = "</body>";
		var newstr = printpage.html();
		var oldstr = J("body").html();
		J("body").html(headstr+newstr+footstr);
		window.print();
		J("body").html(oldstr);
		return false;
	});
	J.method("copy",function(txt){//代码复制函数
		if(window.clipboardData) {  
			window.clipboardData.clearData();  
			window.clipboardData.setData("Text", txt); 
		} else if(navigator.userAgent.indexOf("Opera") != -1) {  
			window.location = txt;  
		} else if (window.netscape) {  
		   try {  
				netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");  
		   } catch (e) {  
				alert("如果您正在使用FireFox！\n请在浏览器地址栏输入'about:config'并回车\n然后将'signed.applets.codebase_principal_support'设置为'true'");  
		   }  
		   var clip = Components.classes['@mozilla.org/widget/clipboard;1'].createInstance(Components.interfaces.nsIClipboard);  
		   if (!clip) return;  
		   var trans = Components.classes['@mozilla.org/widget/transferable;1'].createInstance(Components.interfaces.nsITransferable);  
		   if (!trans) return;  
		   trans.addDataFlavor('text/unicode');  
		   var str = new Object();  
		   var len = new Object();  
		   var str = Components.classes["@mozilla.org/supports-string;1"].createInstance(Components.interfaces.nsISupportsString);  
		   var copytext = txt;  
		   str.data = copytext;  
		   trans.setTransferData("text/unicode",str,copytext.length*2);  
		   var clipid = Components.interfaces.nsIClipboard;  
		   if (!clip) return false;  
		   clip.setData(trans,null,clipid.kGlobalClipboard);  
	  }   
	});
});