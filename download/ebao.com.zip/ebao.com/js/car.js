<?
$inc('widget/Jw_masklayer.js')
$inc('widget/Jw_dialog.js')
$inc('widget/Pw_login.js')
$inc('widget/Pw_weibo.js')
$inc('public/page.js')
?>
J(function(){
	J.block({
		init:function(){
		    this.cityShow();//弹出城市选择
			this.newbuy();//侧边滚动公告
		},
		newbuy:function(){
			J.block({
				init:function(){
					var Jroot=
					this.Jroot=J('#newbuy');
					this.wrap=Jroot.find('.newbuy-wrap');
					this.height=Jroot.height()+2;
					this.lock=0;
					this.top=0;
					this.minTop=-((this.wrap.find('dl').nodes.length-3)*this.height/2);
					this.bind();
					this.autoPlay();
					this.fx='next';
				},
				bind:function(){
					var self=this;
					this.Jroot.find('.prev').click(function(){
						self.prev();
					});
					this.Jroot.find('.next').click(function(){
						self.next();
					});
				},
				next:function(){
					if(this.lock)return;

					if(this.top<=this.minTop){
						this.wrap.append(this.wrap.child(0).node);
						this.wrap.append(this.wrap.child(0).node);
						this.wrap.css('top',this.top+=this.height);
					}
					this.play(-1);
					this.fx='next';
				},
				prev:function(){
					if(this.lock)return;
					if(this.top>=0){
						this.wrap.append(this.wrap.child(-1).node,0);
						this.wrap.append(this.wrap.child(-1).node,0);
						this.wrap.css('top',this.top-=this.height);
					}
					this.play(1);
					this.fx='prev';
				},
				autoPlay:function(){
					var self=this;
					this.timer=setInterval(function(){
						self[self.fx]();
					},4000);
				},
				play:function(fx){
					var self=this;
					this.lock=1;
					this.wrap.anime({
						after:function(){
							self.lock=0;
						},
						stop:'lock',
						y:''+fx*this.height,
						t:600
					});
					this.top+=fx*this.height;
				},
				stop:function(){return
					clearTimeout(this.timer);
				}
				
			});
		},
		cityShow:function(){
		    //城市选择
			J("#gnfromcity").on("focus",function(){
				if(this.val()=="请选择城市"){this.val("");}
				J("#hot_city_down").css({left:J("#gnfromcity").offsetLeft()+2,top:J("#gnfromcity").offsetTop()+27}).show();
			});
			J("#cityList a").each(function(){
				this.click(function(evt){
				   var text=this.html();
				   J("#gnfromcity").val(text);
				   J("#hot_city_down").hide();
				   evt.preventDefault();
				});
			});
			J(document).click(function(evt){
				if(!J("#hot_city_down").contains(evt.target)&&evt.target!= J("#gnfromcity").node){
					J("#hot_city_down").hide();
					if(J("#gnfromcity").val()==""){J("#gnfromcity").val("请选择城市");}
				}
			});
			var focus=0,
				btn=J('#hot_city_down li'),
				box=J('#cityList .tab-pannel');
			btn.each(function(i){
				this.click(function(){
					if(focus!=i){
						btn.eq(focus).cls('-selected');
						box.eq(focus).cls('+hidden');
						btn.eq(i).cls('+selected');
						box.eq(i).cls('-hidden');
						focus=i;
					}
				});
			
			});
		}
	});
});