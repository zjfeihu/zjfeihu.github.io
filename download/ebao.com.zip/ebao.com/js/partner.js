<?
$inc('widget/Jw_masklayer.js')
$inc('widget/Jw_dialog.js')
$inc('widget/Jw_Form.js')
$inc('widget/Pw_login.js')
$inc('widget/Pw_weibo.js')
$inc('widget/Jw_arealinkage.js')
$inc('public/page.js')
?>
J(function(){
	if(J.g('#form1')){
		J.Form('#form1').skin({
			name:'class',
			type:'tips,null,erro',
			data:{
				name:['请务必准确填写公司全称，不得以简称替代。<span class="red">一经提交，不可修改</span>','非空',''],
				address3:['必须包含中文，且不能少于6个字符（1个汉字等于2个字符）','非空',''],
				postcode:['','非空',''],
				number:['请正确填写您的企业营业执照号，这将有利于您的申请快速获得通过。','非空',''],
				numberimg:['上传文件支持jpg/jpeg/bmp/gif后缀的文件，且上传文件大小不超过2M。','非空',''],
				icp:['','非空','请正确填写'],
				legalperson:['','非空',''],
				legalid:['','非空',''],
				email:['邮箱用于相关邮件通知，如帐号开通等，非常重要，请务必准确填写。','非空','格式错误'],
				fax:['区号、分机号用‘-’隔开，如：0755-86013388-888','',''],
				phone:['区号、分机号用‘-’隔开，如：0755-86013388-888','非空',''],
				businessowner:['','非空',''],
				mobile:['','非空',''],
				platform:['','非空',''],
				platformurl:['','非空',''],
				chkcode:['','非空',''],

				end:0
			}
		
		
		});
		J.AreaLinkage({
			node:J('#address').node,
			change:function(){
				//J('#start_areai').val(this.getCity()?1:'');
				//form1.doTest('start_areai');
			}
		});
	}
    /*if(J.g("#partner-step1-001")){
		J("#partner-step1-001 a").each(function(){
			if(this.attr("tips")){
				this.hover(function(){
					this.next("div.tooltips-box").css({top:this.child("img").offsetTop()+83,left:this.child("img").offsetLeft()-13}).show();
				},function(){
					this.next("div.tooltips-box").hide();
				});
			}
		});
	}*/

});