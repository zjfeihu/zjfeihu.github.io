<?
$inc('widget/Jw_masklayer.js')
$inc('widget/Jw_dialog.js')
$inc('widget/Jw_calendar.js')
$inc('widget/Jw_form.js')
$inc('widget/Pw_weibo.js')
$inc('widget/Jw_AreaLinkage.js')
$inc('widget/Jw_tips.js')
$inc('public/page.js')
?>
J(function(){
	/*J("#usernav .showchild").each(function(){
		this.click(function(e){
			this.parent('ul').find('ul').cls("+hidden");
			this.parent('ul').find('strong').cls("-down");
			if(this.parent().next("ul")){
			    this.parent().next().cls("-hidden");
				this.parent().cls("+down")
				e.preventDefault();
			}
	    });
	});*/
	<?
	$inc('admin-center/userorder.js')
	$inc('admin-center/bizbuy.js')
	$inc('admin-center/bizinfo.js')
	$inc('admin-center/bizaddadv.js')
	$inc('admin-center/bizmyadv.js')
	$inc('admin-center/bizprdmanage.js')
	$inc('admin-center/bizdistributor.js')
	?>
	
});

