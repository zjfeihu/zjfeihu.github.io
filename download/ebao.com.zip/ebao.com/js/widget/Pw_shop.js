//购物车浮层组件
J.widget('Pw_shop',function(){
	var config={//默认配置项

	};
	var shop=J.Class({
		show:function(){
			this.box.show();
			this.Jpanel.opacity(0).anime({o:1,t:400});
		},
		hide:function(){
			this.box.hide();
		},
		position:function(option){
			this.box.set({
				left:option.left,
				top:option.top
			});
			return this;
		},
		add:function(apiUrl){
			var self=this;
			J.get(apiUrl,function(result){
				if(result){
					result=result.split('||');
					J('#Pw_shop_num').html(result[0]);
					J('#Pw_shop_price').html(result[1]);
					self.show();
				}
			
			});
			
			
		
		},
		init:function(option){
			var self=this;
			option=option||{};
			J.each(config,function(key){//获取用户配置
				self[key]=option[key]||config[key];
			});
			var self=this;
			J(function(){
				self._create();
			});
		},
		_create:function(){
			this.box=J.Dialog({
				cls:'car-popLayer',
				title:'购物车',
				content:'<div class="car-popLayer-top"></div>\
					<div class="car-popLayer-center">\
						<p class="icon-success">\
							<strong>商品已成功添加到购物车！</strong><br />\
							购物车共有 <span id="Pw_shop_num">0</span> 种商品，合计： <em id="Pw_shop_price">0.00</em> 元\
						</p>\
						<p><a href="cart.php" class="submit">去购物车结算</a></p>\
						<span class="close-layer" jbtn="close">×关闭</span>\
					</div>\
					<div class="car-popLayer-bottom"></div>',
				width:400,
				zIndex:5,
				end:0
			});
			this.Jpanel=this.box.Jpanel;
		}
	});
	return new shop();
});

