J.widget('Tips',function(){
	var Jbody,
	config={//默认配置项
	    content:"默认信息",
		//width:200,
		top:"center",
		left:"center",
		cls:"",
		stopTime:1000,
		animateTime:500
	}
	J(function(){
	   Jbody=J("body").eq(0);
	});
	var Class=J.Class({
		init:function(option){//默认方法
		    this._config(option);
		    this._createHtml();
		},
		show:function(option){
			this.Jpanel.anime({
				o:1,
				t:this.animateTime
			});
			option=option||{};
			if('width' in option){
				this.Jbox.width(this.width=option.width);
			}
			if('content' in option){
				this.Jcontent.html(this.content=option.content);
			}
			this._setPosition();
			this.overlay&&this.overlay.show();
			return this;
		},
		remove:function(){
			var JJ=this.Jpanel;
			setTimeout(function(){
				JJ.anime({
					o:0,
					t:this.animateTime,
					after:function(){
						JJ.remove();
					}
				})
			},this.stopTime);
			this.overlay&&this.overlay.remove();
			return this;
		},
		_config:function(option){
			var me=this;
			option=option||{};
			J.each(config,function(key){
				me[key]=(key in option)?option[key]:config[key];
			});
		},
		_createHtml:function(){
			this.Jpanel=J(J.node('<div class="P_msg" id="P_msg">'+this.content+'</div>')).cls("+"+(this.cls)).css({opacity:0});
			Jbody.append(this.Jpanel.node);
		},
		_setPosition:function(option){
			if(this.left=='center'){
				this.Jpanel.left((J.docWidth()-this.Jpanel.offsetWidth())/2);
			}else{
				this.Jpanel.left(this.left);
			}
			if(this.top=='center'){
				this.Jpanel.top((J.docHeight()-this.Jpanel.offsetHeight())/2);
			}else{
				this.Jpanel.top(this.top);
			}
		}
	});
	
	return function(option){
		return new Class(option);
	};
});