/*
creare at 2011.4.2 by sschen
日历类
使用方法,将需要使用日历的input设置为type="calendar"
<input type="calendar"/>
对外接口：
	J.Calendar.show(input)//参数为需要使用的input
	J.Calendar.hide()//隐藏日历
	J.Calendar.up(year,month)//更新日历,参数为日历的年月
	J.Calendar.style(cssText)//设置日历样式，参数为style字符串
*/
J.widget('Calendar',function(){
	var Jpanel,//日历面板
		Jinput,//焦点中的日历input
		hasShow=0,//已经显示日历
		time=new Date,
		year=time.getFullYear(),//当前的年
		month=time.getMonth() + 1,//当前的月
		_bg=+new Date('1970/1/1'),
		_af=+new Date('2037/1/1'),
		bg=+new Date('1970/1/1'),
		af=+new Date('2037/1/1'),
		end;
	J.block({
		init:function(){
			var bk=this;
			J(function(){
				bk.create();
				up(year,month);
			});
		},
		create:function(){
			Jpanel=J(J.node('<div class="Calendar-default"></div>'));
			J('body').append(Jpanel.node);
			J(document).click(bindEvt).on('keyup',bindEvt);
			Jpanel.click(function(evt){
				switch(J(evt.target).attr('jid')){
					case 'date':
						setVal(J(evt.target).html());
						break;
					case 'nextMonth':
						up(year,month+1);
						break;
					case 'nextYear':
						up(year+1,month);
						break;
					case 'prevYear':
						up(year-1,month);
						break;
					case 'prevMonth':
						up(year,month-1);
						break;
				}
				evt.stopPropagation();
			});
			function bindEvt(evt){
				var target=evt.target;
				if(Jinput&&!Jinput.contains(target)&&Jinput.node!=target){
					hide();
				}
				if(J(target).attr('type')=='calendar'&&(!hasShow||Jinput.node!=target)){
					show(target);
				}
			}
		}
	
	});
	function testLimit(date){
		var _now=+new Date([year,month,date].join('/'));
		if(_now>bg&&_now<af){
			return 1;
		}
	}
	function up(y,m){
		year=y;
		month=m;
		if(m>12){
			year=++y;
			month=m=1;
		}else if(m==0){
			year=--y;
			month=m=12;
		}
		Jpanel.html(function(){
			var now=new Date(y+"/"+m+"/1");
			var html=[
				'<ul><li class="btns"><a href="javascript:;" jid="prevYear" title="上一年">&lt;&lt;</a><a href="javascript:;" jid="prevMonth" title="上一月">&lt;</a><a>'+(y+'.'+m)+'</a><a href="javascript:;" jid="nextMonth" title="下一月">&gt;</a><a href="javascript:;" jid="nextYear" title="下一年">&gt;&gt;</a></li>',//按钮
				'<li><b>日</b><b>一</b><b>二</b><b>三</b><b>四</b><b>五</b><b>六</b></li>',//星期
				'<li>'+new Array(now.getDay()+1).join('<b>&nbsp;</b>'),//空白占位
				new Array(new Date(y+"/"+(m+1)+"/0").getDate()+1).join('_').replace(/_/g,function(_,i){
					return '<a jid="date" href="javascript:;">'+(i+1)+'</a>';
				})+'</li></ul>',
			]
			return html.join('');
		});
		return me;
	}
	function setVal(date){
		if(testLimit(date)){//通过验证
			Jinput.val([year,month,date].join('-'));
			hide();
		}else{
			if(call_erro){
				call_erro();
			}
		}
	}
	function show(input){
		Jinput=J(input);
		//limit设置，时间范围
		var limitArgs=Jinput.attr('limit');
		if(limitArgs){
			limitArgs=limitArgs.split(',');
			limit(limitArgs[0],limitArgs[1]);
		}else{
			limit(_bg,_af);
		}
		if(Jinput.val()){//回显日历
			time=new Date(Jinput.val().replace(/-|\./g,'/'));
			year=time.getFullYear();
			month=time.getMonth() + 1;
			if(time&&+time>bg&&+time<af){
			
			}else{
				time=new Date;
				year=time.getFullYear();
				month=time.getMonth() + 1;
			}
			up(year,month);
		}
		
		Jpanel.css({
			display:'block',
			left:Jinput.offsetLeft(),
			top:Jinput.offsetTop()+Jinput.offsetHeight()
		}).opacity(0).anime({
			o:1,t:200
		});
		hasShow=1;
	}
	function hide(){
		Jpanel.hide();
		Jinput=null;
		hasShow=0;
	}
	function limit(limitBg,limitAf){
		bg=limitBg?+new Date(limitBg):_bg;//开始时间
		af=limitAf?+new Date(limitAf):_af;//结束时间
	}
	var me={
		find:function(selector){
			return me;
		},
		up:up,
		setVal:setVal,
		set:function(opt){
			alert(opt)
		}
	
	};
	return me;

});
