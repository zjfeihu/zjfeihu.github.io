J.widget('Dialog',function(){
	var config={//默认配置项
		content:'hello world!',
		title:'提示',
		drag:false,
		width:160,
		height:'auto',
		left:'center',
		top:'center',
		yes:0,
		no:0,
		bottom:null,
		right:null,
		lock:0,
		zIndex:100,
		cls:''
	};
	var Dialog=J.Class({
		show:function(){
			if(this.lock)this.maskLayer.show();
			this.Jpanel.show();
			this._setPosition();
		},
		hide:function(){
			if(this.lock)this.maskLayer.hide();
			this.Jpanel.hide();
		},
		set:function(option){
			var self=this;
			option=option||{};
			J.each(option,function(key){//获取用户配置
				self[key]=(key in config)?option[key]:config[key];
			});
			if('width' in option){
				this.Jpanel.find('.J_dialog_pbox').width(this.width);
			}
			if('content' in option){
				this.setContent(this.content);
			}
			if('title' in option){
				this.setTitle(this.title);
			}
			return this;
		},
		setContent:function(content){
			this.ctx.html(content);
		},
		setTitle:function(title){
			this.tit.html(title);
		},
		config:function(option){
			var self=this;
			option=option||{};
			J.each(config,function(key){//获取用户配置
				self[key]=(key in option)?option[key]:config[key];
			});
		},
		init:function(option){
			this.config(option);
			this._create();
			this._bind();
			this._config();
		},
		_create:function(){
			var html='<div class="J_dialog '+this.cls+'">'
				+'<div class="J_dialog_bg"></div>'
				+'<div class="J_dialog_pbox">'
					+'<h4 class="J_dialog_title"><em class="J_dialog_tit">'+this.title+'</em><a class="J_dialog_close" jbtn="close" href="javascript:;">×</a></h4>'
					+'<div class="J_dialog_cxt">'+this.content+'</div>'
					+((this.yes||this.no)?('<div class="J_dialog_btns">'
					+(this.no?'<a class="J_dialog_no" jbtn="no" href="javascript:;">取消</a>':'')
					+(this.yes?'<a  class="J_dialog_yes" jbtn="yes" '+(this.no?'':'style="float:none;margin-left:none;"')+'  href="javascript:;">确定</a>':'')
				+'</div>'):'')
				+'</div>'
				+'</div>';
			this.Jpanel=J(J.node(html)).css('zIndex',this.zIndex);
			this.ctx=this.Jpanel.find('.J_dialog_cxt').eq(0);
			this.tit=this.Jpanel.find('.J_dialog_tit').eq(0);
			J('body').append(this.Jpanel.node);
		},
		_bind:function(){
			this.Jpanel.click(function(evt){
				var Jtarget=J(evt.target);
				switch(Jtarget.attr('jbtn')){
					case 'close':
						return this.hide();
					case 'no':
						if(this.no())return this.hide();
						return;
					case 'yes':
						if(this.yes())return this.hide();
						return;
				}
			},this);
		},
		_config:function(){
			var self=this;
			this.Jpanel.find('.J_dialog_pbox').css({
				width:this.width||'auto',
				height:this.height||'auto'
			});
			if(this.lock){
				this.maskLayer=J.MaskLayer();
			}
			if(this.fixed){
				if(J.isIE6){
					if(this.top=='center'){
						J.fixed(this.Jpanel.node,J.win('height')/2);
					}else{
						J.fixed(this.Jpanel.node,this.Jpanel.css('top'));
					}
				}else{
					this.Jpanel.css('position:fixed');
				}
			}
			if(this.drag){
				this.drag.hand=this.Jpanel.find('.J_dialog_title').node||this.Jpanel.node;
				this.drag.hand.style.cursor='move';
				this.Jpanel.drag(this.drag);
			}
		},
		_setPosition:function(){

			if(this.left=='center'&&this.right==null){
				this.Jpanel.css({
					left:(J.docWidth()-this.Jpanel.offsetWidth())/2
				});
			}else{
				if(this.right!=null){
					this.Jpanel.css('left',J.scrollWidth()-this.right);
				}else{
					this.Jpanel.css('left',this.left);
				}
			}
			if(this.top=='center'&&this.bottom==null){
				this.Jpanel.css({
					top:(this.fixed&&!J.isIE6?0:J.scrollTop())+(J.docHeight()-this.Jpanel.offsetHeight())/2
				});
			}else{
				if(this.bottom!=null){
					this.Jpanel.css('top',J.scrollHeight()-this.bottom-this.Jpanel.offsetHeight());
				}else{
					this.Jpanel.css('top',this.top);
				}			
			}
		},
		end:0
	});
	return function(option){
		return new Dialog(option);
	};
});

