J.widget('Form',function(){
	var testType='email,number,url,mobile,tel,password,ponenumber,test',
		testReg={
			number:/^\d+$/,
			email:/^\w+@\w+(\.\w+)+$/,//电子邮箱,比如:123@126.com或123@sina.com.cn等
			url:/^http:\/\/[\w-]+(?:\.[\w-]+)+\/?.*$/i,	//URL地址
			mobile:/^(?:13|15|18)\d{9}$/,//手机13/15/18开头
			tel:/^(\d{3,4}-)?\d{7,8}$/,
			ponenumber:/^(\d{3,4}-)?\d{7,8}$|^(?:13|15|18)\d{9}$/,
			password:/^.{6,16}$/,
			test:/^[\w\W]*$/
		},
		Jfocus,//当前的焦点
		end;
	function init(Jform){
		bind&&bind();
		Jform=J(Jform);
		Jform.cls('+Jform');
		Jform.on('submit',function(evt){
			var hasPass=1;
			J('input',this.node).each(function(){
				if(needTest(this)){
					hasPass--;
					formBox(this);
					hasPass+=doTest(this);
				}
			});
			J('select',this.node).each(function(){
				if(needTest(this)){
					hasPass--;
					formBox(this);
					hasPass+=doTest(this);
				}
			});
			if(hasPass!=1){//没有通过全部验证
				evt.preventDefault();
			}else{
				if(Jform.node.call_pass){
					Jform.node.call_pass.call(Jform,evt);
				}
			}
		});
		var ___fidFunc=Jform.node.___fidFunc={//特殊的验证规则
		
		},self;
		return self={
			skin:function(option){
				skin.call(Jform,option);
				return self;
			},
			addTest:function(fid,testFunc){
				if(!___fidFunc[fid]){
					___fidFunc[fid]=[];
				}
				___fidFunc[fid].push(testFunc);
				return self;
			},
			doTest:function(fid){
				Jform.find('input[fid='+fid+']').each(function(){
					doTest(this);
				});
				return self;
			}
		};
	}
	function bind(){
		bind=null;
		J(function(){
			function test(evt){
				var Jtarget=J(evt.target);
				if(Jfocus&&Jfocus.node!=Jtarget.node){//触发blur
					doTest(Jfocus);
					Jfocus=null;
				}
				if(Jtarget.tag('INPUT')||Jtarget.tag('SELECT')){//触发focus
					if(needTest(Jtarget)){
						Jfocus=Jtarget;
						formBox(Jfocus);
					}
				}
			}
			J(document).click(test).on('keyup',test);
		});
	}
	function needTest(Jnode){
		var need=Jnode.parent('form.Jform').node&&(Jnode.attr('notNull')||testType.indexOf(Jnode.attr('type'))!=-1);
		return need;
	}
	function formBox(Jfocus){
		var Jform=Jfocus.parent('form'),
			parent=Jfocus.parent('.formbox');
		if(!parent.node){
			parent=Jfocus.parent().cls('+formbox');
		}
		if(Jfocus.attr('pid')){
			parent.append(J.node(function(){
				var pid=Jfocus.attr('pid'),
					skinData=Jform.node.skinData[pid],
					html='';
				Jfocus.attr('pid','');
				J.each(['tips','erro','null','pass'],function(){
					if(skinData[this]){
						html+='<em class="'+this+'box">'+skinData[this]+'</em>';
					}
				});
				return '<span class="tipswrap">'+html+'</span>';
			}()));
		}
		Jfocus.parent('.formbox').cls('-isErro,isNull,isPass').cls('+isTips');
	}
	function doTest(Jfocus){
		var Jform=Jfocus.parent('form'),
			parent=Jfocus.parent('.formbox'),
			hasPass=0,//该input是否通过验证
			type=Jfocus.attr('type'),
			val=Jfocus.val(),
			fid=Jfocus.attr('fid');
		parent.cls('-isErro,isNull,isPass,isTips');
		if(Jfocus.attr('notNull')==1&&val==''){//非空验证没通过，退出验证
			parent.cls('+isNull');
			hasPass=0;
			return 0;
		}
		if(val!=''&&testType.indexOf(type)>-1){//对有值的表单进行类型验证
			if(testReg[type].test(val)){//通过类型验证
				hasPass=1;
			}else{
				hasPass=0;
			}
		}else{//无值,非必填写，空值通过验证
			hasPass=1;
		}

		if(hasPass&&fid in Jform.node.___fidFunc){//自定义的验证
			var ___fidFunc=Jform.node.___fidFunc[fid];
			
			for(var i=0,lg=___fidFunc.length;i<lg;i++){
				hasPass-=1;
				hasPass+=(+___fidFunc[i].call(Jform,Jfocus));
			}
			
		}
		parent.cls(hasPass==1?'+isPass':'+isErro')
		return hasPass;
	}
	function skin(option){
		var type=(option.type||'tips,erro,null,pass').split(',');
		this.node.skinData=function(skData){
			var data={};
			for(var key in skData){
				data[key]={};
				for(var i=0,lg=type.length;i<type.length;i++){
					data[key][type[i]]=skData[key][i];
				}
			}
			return data;
		}(option.data||{});
		option.name&&this.cls('+form-'+option.name);
	}
	function addTest(fid,reg){
		
	
	}
	return init;
});