J.widget('AreaLinkage',function(){
	var config={
		provName:'',//省份字段名
		provValue:'-省/直辖市-',//省份值
		cityName:'',
		cityValue:'-地区/城市-',
		change:''//onchange事件
	},
	//{
	areas=[ //省份数据
		{
			prov:'-省/直辖市-',
			city:['-地区/城市-']
		},
		{
			prov: '河北',
			city: ['石家庄', '保定', '沧州', '秦皇岛', '承德', '邯郸', '唐山', '邢台', '廊坊', '衡水', '张家口']
		},
		{
			prov: '山西',
			city: ['太原', '大同', '晋城', '晋中', '临汾', '吕梁', '朔州', '长治', '忻州', '阳泉', '运城']
		},
		{
			prov: '辽宁',
			city: ['沈阳', '大连', '鞍山', '丹东', '抚顺', '本溪', '朝阳', '铁岭', '锦州', '辽阳', '阜新', '葫芦岛', '盘锦', '营口']
		},
		{
			prov: '吉林',
			city: ['长春', '吉林', '四平', '通化', '白城', '白山', '辽源', '松原', '延边朝鲜族自治州']
		},
		{
			prov: '黑龙江',
			city: ['哈尔滨', '大庆', '佳木斯', '鹤岗', '牡丹江', '黑河', '鸡西', '七台河', '齐齐哈尔', '双鸭山', '绥化', '伊春', '大兴安岭']
		},
		{
			prov: '内蒙古',
			city: ['呼和浩特', '包头', '赤峰', '鄂尔多斯', '呼伦贝尔', '阿拉善盟', '通辽', '乌海', '兴安盟', '巴彦淖尔', '乌兰察布盟', '锡林郭勒盟']
		},
		{
			prov: '江苏',
			city: ['南京', '苏州', '无锡', '常州', '淮安', '镇江', '扬州', '徐州', '连云港', '南通', '宿迁', '泰州', '盐城']
		},
		{
			prov: '浙江',
			city: ['杭州', '宁波', '温州', '绍兴', '台州', '嘉兴', '金华', '丽水', '湖州', '衢州', '舟山']
		},
		{
			prov: '安徽',
			city: ['合肥', '芜湖', '马鞍山', '淮南', '蚌埠', '黄山', '阜阳', '淮北', '铜陵', '亳州', '宣城', '安庆', '巢湖', '池州', '六安', '滁州', '宿州']
		},
		{
			prov: '福建',
			city: ['福州', '厦门', '泉州', '漳州', '龙岩', '南平', '宁德', '莆田', '三明']
		},
		{
			prov: '江西',
			city: ['南昌', '上饶', '抚州', '赣州', '九江', '鹰潭', '吉安', '景德镇', '萍乡', '新余', '宜春']
		},
		{
			prov: '山东',
			city: ['济南', '青岛', '烟台', '济宁', '滨州', '莱芜', '日照', '潍坊', '淄博', '德州', '威海', '东营', '菏泽', '聊城', '临沂', '泰安', '枣庄']
		},
		{
			prov: '河南',
			city: ['郑州', '洛阳', '开封', '焦作', '安阳', '南阳', '周口', '商丘', '新乡', '鹤壁', '平顶山', '三门峡', '信阳', '许昌', '驻马店', '漯河', '濮阳']
		},
		{
			prov: '湖北',
			city: ['武汉', '黄冈', '黄石', '荆门', '荆州', '潜江', '宜昌', '鄂州', '十堰', '随州', '天门', '仙桃', '咸宁', '襄樊', '孝感', '神农架林区', '恩施土家族苗族自治州']
		},
		{
			prov: '湖南',
			city: ['长沙', '常德', '株洲', '岳阳', '郴州', '怀化', '湘潭', '张家界', '衡阳', '娄底', '邵阳', '益阳', '永州', '湘西土家族苗族自治州']
		},
		{
			prov: '广东',
			city: ['广州', '深圳', '珠海', '潮州', '中山', '东莞', '佛山', '惠州', '汕头', '汕尾', '韶关', '湛江', '肇庆', '河源', '江门', '揭阳', '茂名', '梅州', '清远', '阳江', '云浮']
		},
		{
			prov: '海南',
			city: ['海口', '三亚', '琼海', '东方', '儋州', '万宁', '文昌', '定安县', '五指山', '屯昌县', '澄迈县', '临高县', '白沙黎族自治县', '昌江黎族自治县', '乐东黎族自治县', '陵水黎族自治县', '琼中黎族苗族自治县', '保亭黎族苗族自治县']
		},
		{
			prov: '广西',
			city: ['南宁', '桂林', '北海', '柳州', '梧州', '玉林', '百色', '崇左', '贵港', '河池', '贺州', '来宾', '防城港', '钦州']
		},
		{
			prov: '四川',
			city: ['成都', '宜宾', '绵阳', '巴中', '攀枝花', '达州', '德阳', '遂宁', '广安', '广元', '乐山', '泸州', '眉山', '南充', '内江', '雅安', '资阳', '自贡', '甘孜藏族自治州', '凉山彝族自治州', '阿坝藏族羌族自治州']
		},
		{
			prov: '贵州',
			city: ['贵阳', '安顺', '毕节', '铜仁', '遵义', '六盘水', '黔东南苗族侗族自治州', '黔南布依族苗族自治州', '黔西南布依族苗族自治州']
		},
		{
			prov: '云南',
			city: ['昆明', '保山', '丽江', '玉溪', '昭通', '临沧', '曲靖', '普洱', '楚雄彝族自治州', '大理白族自治州', '迪庆藏族自治州', '怒江傈傈族自治州', '文山壮族苗族自治州', '西双版纳傣族自治州', '德宏傣族景颇族自治州', '红河哈尼族彝族自治州']
		},
		{
			prov: '西藏',
			city: ['拉萨', '阿里', '昌都', '林芝', '那曲', '日喀则', '山南']
		},
		{
			prov: '陕西',
			city: ['西安', '咸阳', '汉中', '安康', '宝鸡', '商洛', '铜川', '渭南', '延安', '榆林']
		},
		{
			prov: '甘肃',
			city: ['兰州', '白银', '酒泉', '定西', '嘉峪关', '金昌', '庆阳', '陇南', '平凉', '天水', '武威', '张掖', '甘南藏族自治州', '临夏回族自治州']
		},
		{
			prov: '青海',
			city: ['西宁', '海东', '果洛藏族自治州', '海北藏族自治州', '海南藏族自治州', '黄南藏族自治州', '玉树藏族自治州', '海西蒙古族藏族自治州']
		},
		{
			prov: '宁夏',
			city: ['银川', '固原', '石嘴山', '吴忠']
		},
		{
			prov: '新疆',
			city: ['乌鲁木齐', '哈密', '和田', '喀什', '吐鲁番', '阿克苏', '阿拉尔', '石河子', '五家渠', '克拉玛依', '图木舒克', '昌吉回族自治州', '伊犁哈萨克自治州', '巴音郭楞蒙古自治州', '博尔塔拉蒙古自治州', '克孜勒苏柯尔克孜自治州', '塔城地区', '阿勒泰地区']
		},
		{
			prov: '香港',
			city: ['香港岛', '九龙', '新界']
		},
		{
			prov: '澳门',
			city: ['澳门半岛', '澳门离岛']
		},
		{
			prov: '台湾',
			city: ['台北县', '宜兰县', '桃园县', '新竹县', '苗栗县', '台中县', '彰化县', '南投县', '云林县', '嘉义县', '台南县', '高雄县', '屏东县', '台东县', '花莲县', '澎湖县', '基隆市', '新竹市', '台中市', '嘉义市', '台南市', '台北市', '高雄市', '金门县', '连江县']
		}
	],
	map={};
	J.each(areas,function(i){
		map[this.prov]=i;
	});
	//}
	var Class=J.Class({
		init:function(option){
			this.Jroot=J(option.node);
			this._config(option);
			this._createProv();
			this._createCity();
			this._bind();
		},
		_config:function(option){
			var me=this;
			option=option||{};
			J.each(config,function(key){
				me[key]=(key in option)?option[key]:config[key];
			});
			if(option.provValue&&!option.cityValue){
				this.cityValue=areas[map[me.provValue]].city[0];
			}
			if(this.Jroot.attr('provName')){
				this.provName=this.Jroot.attr('provName');
			}
			if(this.Jroot.attr('provValue')){
				this.provValue=this.Jroot.attr('provValue');
			}
			if(this.Jroot.attr('cityName')){
				this.provName=this.Jroot.attr('cityName');
			}
			if(this.Jroot.attr('cityValue')){
				this.cityValue=this.Jroot.attr('cityValue');
			}
			if(this.cityValue){
				this.provValue=this._getProvByCity(this.cityValue);
			}
		},
		_createProv:function(){
			var ht=[];
			J.each(map,function(name){
				ht.push('<option value="'+name+'">'+name+'</option>');
			});
			this.Jprov=J(J.node('<span class="provwrap"><select name="'+this.provName+'">'+ht.join('')+'</select></span>')).child();
			this.Jroot.append(this.Jprov.parent().node);
			this.Jprov.val(this.provValue);
			
		},
		_createCity:function(){
			var me=this;
			if(!this.Jcity){
				this.Jcity=J(J.node('<span class="citywrap"><select name="'+this.cityName+'"></select></span>')).child();
				this.Jroot.append(this.Jcity.parent().node);
			}
			this.Jcity.html('');
			var ht=[];
			J.each(areas[map[this.provValue]].city,function(i){
				ht[i]='<option value="'+this+'">'+this+'</option>';
			});
			J.each(J.g('option',J.node('<div><select>'+ht.join('')+'</select></div>').firstChild),function(){
				me.Jcity.append(this);
			});
			this.Jcity.val(this.cityValue);
		},
		_bind:function(){
			var me=this;
			this.Jprov.on('change',function(){
				me.provValue=this.val();
				me.cityValue=areas[map[me.provValue]].city[0];
				me._createCity();
			});
			if(this.change){
				this.Jprov.on('change',function(){
					me.change.call(me);
				});
				this.Jcity.on('change',function(){
					me.change.call(me);
				});
			}
		},
		_getProvByCity:function(city){
			var prov=areas[0].prov;
			J.each(areas,function(){
				var _prov=this.prov;
				J.each(this.city,function(){
					if(this==city){
						prov=_prov;
					}
				});
			});
			return prov;
		},
		getProv:function(){
			return this.Jprov.val();
		},
		getCity:function(){
			var val=this.Jcity.val();
			if(val==areas[0].city[0]){
				return null;
			}
			return this.Jcity.val();
		},
		end:0
	
	});
	return function(option){
		return new Class(option);
	
	};
});