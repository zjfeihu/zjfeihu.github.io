J.widget('MaskLayer',function(){
	var config={//默认配置项
		bgcolor:'#000',
		opacity:0.4,
		zIndex:10,
		clickClose:0,
		overlay:0//默认全屏
	};
	var MaskLayer=J.Class({
		show:function(){
			this._resize();
			J(window).on('resize',this._resize,this);
			this.Jroot.show().opacity(this.opacity);
		},
		hide:function(){
			J(window).un('resize',this._resize,this);
			this.Jroot.hide();
		},
		init:function(option){
			var self=this;
			option=option||{};
			J.each(config,function(key){//获取用户配置
				self[key]=option[key]||config[key];
			});
			this._create();
		},
		_create:function(){
			var Jroot=this.Jroot=J(J.node('<div style="display:none;"></div>'));
			this.Jroot.css({
				position:'absolute',
				background:this.bgcolor,
				zIndex:this.zIndex,
				width:'100%',
				height:'100%',
				left:0,
				top:0
			});
			this._repairIE6();
			J('body').append(Jroot.node);
			if(this.clickClose){
				if(J.isIE6){
					var me=this;
					this.Jroot.find('iframe').node.contentWindow.window.document.onclick=function(){me.hide();};
				}else{
					this.Jroot.click(this.hide,this);
				}
			}
		},
		_repairIE6:function(){
			if(J.isIE6){
				this.Jroot.append(J.node('<iframe style="position:absolute;display:block;left:0;top:0;width:100%;height:100%;background:000;filter:alpha(opacity=0)"></iframe>'));
			}
		},
		_resize:function(){
			if(this.overlay){
				this.Jroot.css({
					width:this.overlay.offsetWidth,
					height:this.overlay.offsetHeight,
					left:this.overlay.offsetLeft,
					top:this.overlay.offsetTop
				});
			}else{
				this.Jroot.css({
					position:J.isIE6?'absolute':'fixed'
				});
				if(J.isIE6){
					this.Jroot.css({
						width:J.scrollWidth(),
						height:J.scrollHeight()
					});
				}
			
			}
		}
		
	});
	return function(option){
		return new MaskLayer(option);
	
	};
});