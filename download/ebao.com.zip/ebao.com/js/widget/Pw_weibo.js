J(function(){
	if(J.g('#open-weibo')){
		/*var d1=J.Dialog({
			cls:'Pw_box',
			title:'易保网 官方微博',
			width:380,
			lock:1,
			content:'<ul class="weibo-box clearfix">\
			  <li><a href="http://weibo.com/ebao88" target="_blank"><img width="150" height="62" src="css-recode/images/sinaweibo.png"></a></li>\
			  <li><a href="http://t.qq.com/ebao88" target="_blank"><img width="150" height="62" src="css-recode/images/qqweibo.png"></a></li>\
			  <li><a href="http://t.163.com/ebao88" target="_blank"><img width="150" height="62" src="css-recode/images/163weibo.png"></a></li>\
			  <li><a href="http://ebao88.t.sohu.com" target="_blank"><img width="150" height="62" src="css-recode/images/sohuweibo.png"></a></li>\
			  <li><a href="http://www.kaixin001.com/home/?uid=105812907" target="_blank"><img width="150" height="62" src="css-recode/images/kx001weibo.png"></a></li>\
			  <li><a href="http://www.renren.com/ebao88/" target="_blank"><img width="150" height="62" src="css-recode/images/renrenweibo.png"></a></li>\
			  </ul>'
		
		});
		J('#open-weibo').click(function(){
			d1.show();
		});*/
		var timer;
		J("#open-weibo").on("mouseover",function(){
			clearTimeout(timer);
			var _this=this;
			timer=setTimeout(function(){
			    _this.find("ul.weibo-box").cls("-hidden");
		    },100);
		}).on("mouseout",function(){
			clearTimeout(timer);
			var _this=this;
			timer=setTimeout(function(){
			   _this.find("ul.weibo-box").cls("+hidden");
		    },100);
		});
	}
});