J(function(){
	if(J.g('#topSearchForm')){//搜索框
		var tips='保险卡';
		
		J("#word").on("focus",function(){
			if(this.val()==tips){
				this.css('color:#333').val('');
			}
		}).on("blur",function(){
			if(this.val()==''){
				this.css('color:#ccc').val(tips);
			}
		}).css('color:#ccc').val(tips);
	
	
		return
	    if(J.g("#word")){
	        J("#word").val("");
		}
		J("#sch-tips").click(function(){
		    J("#word").node.focus();
		});
		J("#word").on("focus",function(){
		    J("#sch-tips").hide();
		}).on("blur",function(){
		    if(!this.val()){
			    J("#sch-tips").show();
		    }
		});;
	}
});