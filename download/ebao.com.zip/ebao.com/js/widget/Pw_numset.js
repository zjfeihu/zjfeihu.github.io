J.widget('Numset',function(){
J(function(){
	if(!J.g('#st-data'))return;
	J('#st-data input.num').each(function(){
		var val=this.val(),
			limit=+this.attr('limitnum');
		this.on('focus',function(){
			val=this.val();
			
		}).on('keyup',function(){
			this.val(this.val().replace(/\D/g,''));
		}).on('blur',function(){
			this.val(this.val().replace(/\D/g,''));
			if(this.val()>0&&this.val()<=limit){
				setNum(this);
			}else{
				this.val(val);
			}
		});
	});
	J('#st-data span.reduce').each(function(){
		this.click(function(){
			var Jinput=this.sibling('input');
			if(+Jinput.val()>1){
				Jinput.val(Jinput.val()-1);
				setNum(Jinput);
			}
		});
	});
	J('#st-data span.add').each(function(){
		var limit=+this.sibling('input').attr('limitnum');
		this.click(function(){
			var Jinput=this.sibling('input');
			if(+Jinput.val()<limit){
				Jinput.val(+Jinput.val()+1);
				setNum(Jinput);
			}
		});
	});
	function setNum(Jinput){
		J.get(Jinput.attr('data-url')+'&num='+Jinput.val(),function(result){
			if(result){
				try{
					result=eval('('+result+')');
					if(result.res==1){
						J('#total-price').html('&yen; '+result.totalPrice);
					}
				}catch(e){}
			}
		});
	}
});
	return{};
});