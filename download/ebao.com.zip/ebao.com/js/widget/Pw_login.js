//登录浮层组件
J.widget('Pw_login',function(){
	var config={//默认配置项

	};
	var login=J.Class({
		show:function(){
			this.box.show();
		},
		hide:function(){
			this.box.hide();
		},
		init:function(option){
			var self=this;
			option=option||{};
			J.each(config,function(key){//获取用户配置
				self[key]=option[key]||config[key];
			});
			var self=this;
			J(function(){
				if(J('a.tologin').node){
					self._create();
					self._bind();
				}
			});
		},
		_create:function(){
			this.box=J.Dialog({
				cls:'Pw_box',
				title:'用户登录',
				content:'<form class="loginbox" method="post" action="login.php" onsubmit="return false;">\
					<fieldset>		\
						<legend>用户登录</legend>\
						<ul class="left-ul">\
							<li>\
								<label for="username" class="fz14">用户名：</label>\
								<input class="text" type="text" default="请输入邮箱邮箱" name="username"/>\
							</li>\
							<li>\
								<label for="password" class="fz14">密　码：</label>\
								<input type="password" class="text" default="请输入密码" name="password"/>\
							</li>\
							<li>\
							<label for="code" class="fz14">验证码：</label>	\
								<input class="text codeNumber" name="code"> \
								<img src="captcha.php" onclick="this.src=\'captcha.php?ran=\'+Math.random()"/> <a href="javascript:void(0)" id="changeImg">看不清，换一张</a>\
							</li>\
							<li class="libtn">\
							<span id="login-msg"></span>	 \
								<button>登录</button> <input class="remerber" type="checkbox" id="remerber" name="checkbox">			\
								<label for="remerber">记在登录状态</label>\
							</li>\
						</ul>\
						<div class="left-reg"><strong>没有帐号？<a href="reg.php">立即注册</a></strong><br /><a href="password.php?act=forget" class="left-forget">找回密码</a></div>\
					</fieldset>		\
				</form>',
				drag:{
					limitNode:window
				},
				width:496,
				lock:1
			});
			this.Jpanel=this.box.Jpanel;
		},
		_bind:function(){
			var self=this;
			J('.tologin').click(function(evt){
				self.show();
				evt.preventDefault();
			});
			J("#changeImg").click(function(e){
				this.prev("img").attr("src","captcha.php?ran="+Math.random());
				e.preventDefault();
			});
			var Jname=this.Jpanel.find('input[name=username]'),
				Jpwd=this.Jpanel.find('input[name=password]'),
				Jcode=this.Jpanel.find('input[name=code]');
			this.Jpanel.find('button').click(function(){
				J.get('login.php',function(result){
					if(result){
						try{
							result=eval('('+result+')');
							if(result.res==1){
								location.href=location.href;
							}else{
								J("#login-msg").html(result.msg);
							}
						}catch(e){J("#login-msg").html('网络异常，请稍候再试！');}
					}else{
						J("#login-msg").html('网络异常，请稍候再试！');
					}
				},{
					act:'ajaxlogin',
					username:Jname.val(),
					password:Jpwd.val(),
					code:Jcode.val()
				});
			
			});
		}
	});
	return new login();
});