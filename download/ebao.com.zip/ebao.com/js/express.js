<?
$inc('widget/Jw_masklayer.js')
$inc('widget/Jw_dialog.js')
$inc('widget/Pw_login.js')
$inc('widget/Jw_form.js')
$inc('widget/Jw_rbanLinkage.js')
$inc('widget/Pw_weibo.js')
$inc('public/page.js')
?>
J(function(){
	var form1=J.Form('#form1').skin({
		name:'class',
		type:'tips,erro,null',
		data:{
			companyid:['','填写正确的格式','此项为必填项'],
			//exp_num:['必须凭 2011年04月27日 的快递单/邮单才可投保','填写正确的格式','您还没有输入快递单号'],
			start_area:['请选择始发地','填写正确的格式','您没有未选择始发地'],
			end_area:['请选择目的地','填写正确的格式','您还没有选择目的地'],
			t_person:['请输入投保人名称','填写正确的格式','您还没有输入投保人名称'],
			b_person:['请输入被保险人名称','填写正确的格式','您还没有输入被保险人名称'],
			phone:['请输入常用电话或手机号码','填写正确的格式','您还没有输入联系电话'],
			email:['请输入常用电子邮箱','电子邮箱格式不正确','您还没有输入电子邮箱'],
			address:['请输入联系地址','填写正确的格式','您还没有输入联系地址'],
			ware_type:['请选择货物种类','填写正确的格式','您还没有选择货物种类'],
			ware_name:['请输入货物名称及型号','填写正确的格式','您还没有输入名称及型号'],
			pack_type:['请选择货物包装方式','填写正确的格式','您还没有选择包装方式'],
			ware_number:['请输入货物件数','只能输入数字','您还没有输入货物件数'],
			ware_weight:['货物重量','只能输入数字或小数','您还没有输入货物重量'],
			ware_vol:['货物体积','只能输入数字或小数','您还没有输入货物体积'],
			price:['（您的货物价值 ，最高承保20000元）','只能输入数字或小数','您还没有输入投保金额']
		}
	
	
	});
	new J.UrbanLinkage('#start_area',{
		pname:'exp[start_province]',
		cname:'exp[start_city]',
		change:function(){
			J('#start_areai').val(this.getCity()?1:'');
			//form1.doTest('start_areai');
		}
	});
	new J.UrbanLinkage('#end_area',{
		pname:'exp[end_province]',
		cname:'exp[end_city]',
		change:function(){
			J('#end_areai').val(this.getCity()?1:'');
			//form1.doTest('end_areai');
		}
	});
	J('#price').on('keyup',function(){
		var val=this.val(); 
		this.val(this.val().replace(/\D/g,''));
		if(this.val()>=1000){
			J('#ins_price').html((this.val()*0.002).toFixed(2));
		}else{
			J('#ins_price').html('2.00');
		}
	});







});
