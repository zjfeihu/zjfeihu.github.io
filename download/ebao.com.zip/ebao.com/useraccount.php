<?
$ID='admin-center';
$html='user/useraccount';
$nav=0;
$pagename='账号管理';
$itemname='账号历史';
$inc('templates/layout.html');
?>
