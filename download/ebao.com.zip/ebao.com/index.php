<?
	$ID = 'index';
	$nav = 1;
	$inc('templates/layout.html');
?>