<?
$ID='group';
$nav=1;
$inc('templates/layout.html');
?>