<?
	$ID='car';
	$nav=1;
	$inc('templates/layout.html');
?>