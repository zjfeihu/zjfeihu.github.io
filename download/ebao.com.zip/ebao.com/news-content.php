<?
$ID='news';
$html='news-content';
$nav=1;
$inc('templates/layout.html');
?>
