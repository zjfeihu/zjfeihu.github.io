<?
$ID='admin-center';
$html='biz/bizsell';
$nav=0;
$pagename='销售管理';
$itemname='';
$inc('templates/layout.html');
?>
