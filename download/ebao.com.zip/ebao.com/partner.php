<?
$ID='partner';
$html='partner/partner-'+($GET['s']||1);
$nav=0;
$inc('templates/layout.html');
?>
