<?
if($GET['action'] == 'addToCart'){
    $push(1);
}else if($GET['action'] == 'delCart'){
    $push('{"res":1}');
}else{
    $ID='cart';
    $nav=1;
    $inc('templates/layout.html');
}

?>