<?
$ID='admin-center';
$html='user/userpost';
$nav=0;
$pagename='账号管理';
$itemname='邮寄人信息';
$inc('templates/layout.html');
?>
