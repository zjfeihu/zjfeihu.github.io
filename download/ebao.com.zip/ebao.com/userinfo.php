<?
$ID='admin-center';
$html='user/userinfo';
$nav=0;
$pagename='账号管理';
$itemname='我的资料';
$inc('templates/layout.html');
?>