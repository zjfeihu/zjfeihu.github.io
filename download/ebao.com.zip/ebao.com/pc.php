<!doctype html>
<html>
<head>
<meta charset="utf-8"/>
<meta name="description" content="易保网" />
<meta name="keywords" content="易保网" />
<title>保险评测-易保网</title>
<link href="css/pc.css" rel="stylesheet" />
<script src="js/lib-v1.js"></script>
<script src="js/pc.js"></script>
<!--[if IE 6]>
<script src="js/DD_belatedPNG.js"></script>
<script>
  DD_belatedPNG.fix('.home img,#index .logo,#index .contact-index,#begin,#scrollBar li span,#scrollBar-gg,#rrt img');
</script>
<![endif]-->
</head>

<body>
<div id="logo"><a href="#" target="_self" title="易保网" class="home"><img src="css/images/pc/logo2.png" width="348" height="63" alt="易保网"/></a></div>
<div class="main">
   <div class="titbox" id="titbox">
		<span class="title"><span class="ll"></span><span class="rr" id="rrt"><img/></span></span>
   </div>
   <div class="content">
		<div id="index">
			<div class="logo"></div>
			<div class="contact-index"></div>
			<div class="but-c"><a href="javascript:;"><button type="button" class="test-btn" id="begin" >马上开始</button></a></div>
		</div>
		<ol id="order"></ol>
		<form id="form">
			
		<div class="logo"></div>
		  <ul class="check-contact">
			<li><label for="username">姓名：</label><input id="username" name="username" type="text"></li>
			<li><label for="tel">电话：</label><input id="tel" name="tel" type="text"></li>
			<li><label for="email">Email：</label><input id="email" name="email" type="text"></li>
			<li class="but-r"><a href="javascript:;"><button name="btn" type="submit" class="test-btn" id="submit">下一步</button></a>
			</li>
		  </ul>
		  <div class="show">请认真填写，我们将会相关信息发送到您的邮箱。</div>
 
		</form>
   </div>
   <div class="scrollBar-gg" id="scrollBar-gg"></div>
   <div class="scroll" id="scroll">
      <div class="prev"><a id="prev" title="上一步" href="javascript:;">上一步</a></div>
      <div class="bar">
         <ol id="scrollBar" class="scrollBar">
		 <?
			$each(15,function(i){
				$push('<li><span class="b'+(this+1)+'"></span></li>');
			});
		 
		 ?>
         </ol>
      </div>
      <div class="next"><a id="next" class="on" title="下一步" href="javascript:;">下一步</a></div>
   </div>
   <div class="footer">CopyRight ©2010-2012 ebao88.com, Inc. All Rights Reserved </div>
</div>

</body>
</html>
