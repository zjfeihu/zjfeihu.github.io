<?
$ID='admin-center';
$html='biz/bizseller';
$nav=0;
$pagename='商家资料';
$itemname='我的销售员';
$inc('templates/layout.html');
?>
